package NCAT::ConfData;
use strict;
use base 'NCAT::ConfObj';

# hide pseudo-hash warning in 5.8
no warnings 'deprecated';
#

=head1 NAME

NCAT::ConfData - Class that implements NCAT data element type

=head1 SYNOPSIS

  use 'NCAT::ConfData';

  # create new object

  $element = new NCAT::ConfData(name=>"ExternalIF",
			      description=>"Primary external interface",
			      defaultvalue=>"Ethernet0",
			      howtoget=>"show ip interface brief",
			      selected="yes"
			      );

  # Unique (non-inherited) field names/purpose
  #
  #   defaultvalue		- default value
  #   value			- actual value
  #   howtoget			- how to get the data



  # get/set methods are defined for all fields

  $element->value("FastEthernet0/0");
  my $name = $element->value;

  # debugging/diagnostic

  $element->dump;

=head1 DESCRIPTION

  This module defines the datatype for NCAT data elements.
  Data elements are derived from the basic ConfObj datatype
  and have additional fields of: value, defaultvalue, and howtoget.
  

=head1 AUTHOR

George M. Jones

=head1 SEE ALSO

NCAT::ConfData, NCAT::Conf

=cut

#
# $Log: ConfData.pm,v $
# Revision 3.0.6.1  2004/05/11 20:06:24  nziring
# Disabled warnings about deprecated Perl features.
#
# Revision 3.0  2003/05/14 11:30:06  george
# Bring everthing up to at least 3.0
#
# Revision 1.2  2003/05/13 15:03:14  george
# Merge 2.0 into mainline
#
# Revision 1.1.2.8  2003/01/11 08:56:07  gmj
# * Update for 2.0ChangeLog.txt
#
# Revision 1.1.2.7  2002/11/17 17:02:16  gmj
# * selected attribute is now yes/no
#
# Revision 1.1.2.6  2002/11/09 15:33:16  gmj
# * Updated dump routine to print out either heirarcy or parsable config
#
# Revision 1.1.2.5  2002/11/07 15:12:14  gmj
# * Added validation checking for required fields
#
# Revision 1.1.2.4  2002/10/08 15:21:30  gmj
# * development snapshot
#
# Revision 1.1.2.3  2002/10/04 11:16:28  gmj
# * development snapshot
#
#

use fields qw(defaultvalue howtoget);

sub new {
  my $class = shift;
  my $self = fields::new($class);

  # call base class constructor

  $self->SUPER::new(@_);

  # set defaults

  $self->{defaultvalue} = undef;
  $self->{howtoget} = "";
  $self->{selected} = "yes";


#  # Check for required values
#
#  unless (defined($self->{name})) {
#    warn("ConfObj->new requires a name");
#    return undef;
#  }
#

  return $self;
}

sub defaultvalue {
  my NCAT::ConfData $self = shift;
  $self->{defaultvalue} = shift if @_;
  return $self->{defaultvalue};
}

sub howtoget {
  my NCAT::ConfData $self = shift;
  $self->{howtoget} = shift if @_;
  return $self->{howtoget};
}


sub dump {
  my NCAT::ConfData $self = shift;
  my $prefix = shift;
  my $fh = shift;

  $self->SUPER::dump($prefix,$fh);

  $self->dump_line ($fh, "${prefix}DefaultValue:$self->{defaultvalue}\n")
    if (defined $self->{defaultvalue} and not $self->{defaultvalue} =~ /^\s*$/);

  $self->dump_line ($fh, "${prefix}HowToGet:$self->{howtoget}\n")
    if (defined $self->{howtoget} and not $self->{howtoget} =~ /^\s*$/);
  print $fh "\n";
  
  }



1;
