This file describes things you might want to know about
the Router Audit Tool (rat).  rat is a free tool for
checking the configuration of Cisco routers and PIX
firewalls, and similar files.

INSTALL-AND-GO

  See etc/INSTALL.txt for quick-start instructions.

FOR MORE USEFUL READING

  See the doc/ directory.  It contains documentation
  for each program that is a part of the router
  audit tool in text, html and man formats.

RELEASE FILES

  The files in the tar file for this release are:


  Programs:

    rat/bin
    rat/bin/snarf.PL
    rat/bin/ncat.PL
    rat/bin/rat.PL
    rat/bin/ncat_bench.PL
    rat/bin/ncat_config.PL
    rat/bin/ncat_report.PL
    rat/doc

  Documentation:

    rat/doc/NCAT::Conf.3pm
    rat/doc/NCAT::ConfClass.3pm
    rat/doc/NCAT::ConfData.3pm
    rat/doc/NCAT::ConfGlobal.3pm
    rat/doc/NCAT::ConfObj.3pm
    rat/doc/NCAT::ConfRule.3pm
    rat/doc/NCAT::Mailer.3pm
    rat/doc/NCAT::TaggedText.3pm
    rat/doc/ncat.1
    rat/doc/ncat.html
    rat/doc/ncat.txt
    rat/doc/ncat_report.1
    rat/doc/ncat_report.html
    rat/doc/ncat_report.txt
    rat/doc/rat-logo-try1.gif
    rat/doc/rat-splash-3.bmp
    rat/doc/rat-splash-try3.eps
    rat/doc/rat-splash-try3.tif
    rat/doc/rat.1
    rat/doc/rat.html
    rat/doc/rat.txt
    rat/doc/snarf.1
    rat/doc/snarf.html
    rat/doc/snarf.txt

  General Release Information:

    rat/ChangeLog.txt
    rat/README.txt
    rat/install.bat

  Makefiles

    rat/Makefile-nosnarf.PL
    rat/Makefile.PL
    rat/winmake-nosnarf.PL
    rat/winmake.PL

  Benchmarks and Questionnaires:

    Can be downloaded from: http://benchmarks.cisecurity.org
    
  Contributed/Extra files

    rat/contrib
    rat/contrib/code
    rat/contrib/code/IOSsanitizer.pl
    rat/contrib/doc
    rat/contrib/doc/rule-callouts.pod
    rat/contrib/proposals
    rat/contrib/proposals/ConfigFileProposal.txt
    rat/contrib/proposals/Rat1.2-Callout-Design.html
    rat/contrib/proposals/Rat1.2-email_notification-Proposal.html

  ncat/rat configuration files for Cisco IOS

    rat/etc
    rat/etc/configs
    rat/etc/configs/cisco-ios
    rat/etc/configs/cisco-ios/cis-level-1.conf
    rat/etc/configs/cisco-ios/cis-level-2.conf
    rat/etc/configs/cisco-ios/common.conf
    rat/etc/configs/cisco-ios/contexts.txt
    rat/etc/configs/cisco-ios/fields.txt
    rat/etc/configs/cisco-pix
    rat/etc/configs/cisco-pix/cis-level-1.conf
    rat/etc/configs/cisco-pix/cis-level-2.conf
    rat/etc/configs/cisco-pix/common.conf
    rat/etc/configs/cisco-pix/contexts.txt
    rat/etc/configs/cisco-pix/fields.txt

  More General Release Info

    rat/etc/CIS_TERMS.txt
    rat/etc/FAQ.txt
    rat/etc/INSTALL.WIN32.txt
    rat/etc/INSTALL.txt
    rat/etc/INSTALL.unix.txt
    rat/etc/LICENSING.txt
    rat/etc/LOCALIZE.txt
    rat/etc/NSA_NOTICE.txt
    rat/etc/README.WIN32.txt
    rat/etc/README.PIX.txt
    rat/etc/RELEASE-NOTES.txt
    rat/etc/WISHLIST.txt

  Benchmark Source Files

    rat/etc/tex
    rat/etc/tex/Makefile.benchmark
    rat/etc/tex/README
    rat/etc/tex/bench-common.tex
    rat/etc/tex/bench.tex
    rat/etc/tex/questionnaire.tex

  ncat/rat perl modules

    rat/lib
    rat/lib/NCAT
    rat/lib/NCAT/ConfClass.pm
    rat/lib/NCAT/Conf.pm
    rat/lib/NCAT/ConfData.pm
    rat/lib/NCAT/ConfGlobal.pm
    rat/lib/NCAT/ConfObj.pm
    rat/lib/NCAT/ConfRule.pm
    rat/lib/NCAT/IOSCallouts.pm
    rat/lib/NCAT/IOSTest.pm
    rat/lib/NCAT/Mailer.pm
    rat/lib/NCAT/TaggedText.pm
    rat/lib/NCAT.pm

  ncat/rat test files

    rat/t
    rat/t/ncat.conf
    rat/t/fail11
    rat/t/fail12
    rat/t/ncat1.conf
    rat/t/pass12
    rat/t/pass12-level1
    rat/t/placeholder.t
    rat/t/test.t

HOW YOU CAN HELP

  See WISHLIST.txt

AUTHOR

  George M. Jones

MAJOR CONTRIBUTORS

  See Rat documentation.

FEEDBACK 

  Please send bugs/feedback to 

    rat-feedback@cisecurity.org

$Id: README.txt,v 3.0.6.1 2004/05/24 17:18:59 nziring Exp $
