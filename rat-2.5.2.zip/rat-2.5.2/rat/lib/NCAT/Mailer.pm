# perl module
#
#   NCAT::Mailer
#
# Written by: Peter A. Bakke
# Started:    12 March 2002
#
# Last modified: 12 April 2002
#

package NCAT::Mailer;

use vars qw(@ISA @EXPORT @EXPORT_OK $VERSION);
@ISA = (Exporter);
@EXPORT = qw();
@EXPORT_OK = qw(sendAll sendEach sendMail mailerDefaults error);

=head1 NAME

  NCAT::Mailer v. 0.1 - Send e-mail message with attachments

=cut

$VERSION = "0.1";

# Package name.
my $Pkg = *{VERSION}{PACKAGE};

=head1 SYNOPSIS

 use NCAT::Mailer qw(sendMail);

 $code = sendMail(
            To      => 'some@address.com',
            Subject => 'Here is the file',
            Message => "I'm sending you the list you wanted.",
            From    => 'user@local.com',
            SMTP    => 'mailhost.local.com',
            File    => 'filename.txt');

=head1 DESCRIPTION

B<NCAT::Mailer> is a module used to send e-mail messages
using either a sendmail command or directly through an SMTP
server. Files can optionally be specified for inclusion as
MIME attachments.

This module should run under either Windows or Unix-like
systems (SMTP server needs to be specified for Windows use).

=head1 PARAMETERS

The following parameters are recognized:

  to       List of e-mail address to send message to.
  cc       List of e-mail address to send message to.
  bcc      List of e-mail address to send message to. This list
           is removed from the header before the message is sent.
  from     E-mail address of sender.
  subject  The subject of the message.
  message  The body (text) of the message.
  msg      Same as 'message'.
  file     File name or reference to list of files to
           include as attachments.
  files    Same as 'file'.
  smtp     Name of SMTP server.
  sendmail Command used to run sendmail. This must start with a '/',
           contain any necessary flags, and process a message from
           standard input as '/usr/lib/sendmail' does.
  cmd      Same as 'sendmail'.
  mailer   Command to run mail program (not currently implemented).
  type     Data type for body of message.
  filetype Data type for file attachments (use only when all files
           are the same type).
  encoding Encoding to use for non-text files.

The case of the parameters is ignored, so 'to', 'To', and 'TO'
are all equivalent.

The mailing functions (sendAll, sendEach, and sendMail) all use
named parameters. These parameters may be passed directly in the
function argument list (alternating names and values) or in through
hash or array references:

  use NCAT::Mailer qw(sendAll);

  @arr = (to => 'user1@sample.com', cc => 'user2@example.org');
  %hsh = (to => 'user3@dummy.net', bcc => 'user4@someplace.com');

  $error = sendAll(\@arr, \%hsh, 'from', 'sender@local.org',
                   'smtp', 'smtp.local.org', msg => $msgString,
                   subject => 'Here are some files',
                   file => $filename, files => \@fileList);

Parameters that can take on multiple values, such as 'to'
and 'file', are concatenated when specified multiple times.
Scalar parameters, such as 'from' and 'subject', take on
the last value found.

To set default values for calls to sendEach, sendAll, or sendMail,
use the mailerDefaults function. Values set in this function will
be used for any parameters not specified by the 'send' calls.

  use NCAT::Mailer qw(sendMail mailerDefaults);

  mailerDefaults(From     => 'sender@local.org',
                 SMTP     => 'smtp.local.org',
                 Encoding => 'base64');

  @arr = (to => 'user1@sample.com', cc => 'user2@example.org');
  %hsh = (to => 'user3@dummy.net', bcc => 'user4@someplace.com');

  $error = sendMail(\@arr, \%hsh, msg => $msgString,
                   subject => 'Here are some files',
                   file => $filename, files => \@fileList);

Any parameters passed to a I<send> command will be saved as a default
values for future calls to the 'send' commands (except 'to', 'cc',
and 'bcc').

Note: This module does not do SMTP authentication.  If your
mail server strictly requires authentication, you cannot use
this module to send SMTP mail.

Note: The parameters for the mailing agent (smtp, sendmail,
command, and cmd) are actually all the same. The program
determines whether to use the parameter as a command line
call or an SMTP server name based on whether or not the
parameter string starts with a '/'.

=head1 FUNCTIONS

=over 4

=item mailerDefaults

NCAT::Mailer::mailerDefaults(<parameter list>);

  Use this function to set default values for the I<send>
  functions. See the PARAMETERS section for an example.

  If the first parameter is the string 'clear', then the
  previous default values are deleted before any other values
  are added.

=item sendAll

NCAT::Mailer::sendAll(<parameter list>);

  This function is identical to sendMail();

=item sendEach

NCAT::Mailer::sendEach(<parameter list>);

  This function calls sendMail(<parameter list>) for each
  address in the 'to', 'cc' and 'bcc' fields. This allows
  a message to be sent so that the recipients do not see
  the addresses of the other recipients at a cost of having
  to send the message multiple times (once for each recipient)
  instead of just once.

  It is also possible to put all recipients in the 'bcc'
  list to send the message only once, but this may trigger
  some SPAM filters.

  Return 0 on success, error message on failure.

  If there is an error with one address, the error message
  will be saved and the function will continue trying the
  rest of the addresses. The final error message returned
  will be a string of lines containing all error messages
  returned appended with the address that was attempted.
  
  Also see description of sendMail() function.

=item sendMail

NCAT::Mailer::sendMail(<parameter list>);

  This function sends a mail message to the specified recipients with
  the given parameters. (See PARAMETERS for a description of these.)

  There must be at least one recipient address specified (in 'to',
  'cc', and/or 'bcc') for a message to be sent. It is also recommended
  that the 'smtp' server name be set (or the 'sendmail' command, which
  probably only works on Unix-like systems). Also recommended are the
  'from' and 'subject' parameters.

  Return 0 on success, error message on failure.
  
=item error

NCAT::Mailer::error()

  Returns the error message for the last error set in the module, if any,
  returns 0 otherwise.

=back

=cut

use IO::Socket;
use strict;
use 5.005;

# Default values from module configuration file.
my %_Defs;

# Default configuration (initialized from config file settings).
my %Defs = %_Defs if %_Defs;

# Default parameters (in case nothing else is set, try these).
my @SmtpServers = qw(smtp mail);
my $SendmailCmd = '/usr/lib/sendmail -t -oi';

# Parameters which may contain array references.
my %ArrayParam = map { ($_, 1) } qw(to cc bcc file files);

# Valid and default encodings.
my %ValidEncoding = map { ($_, 1) }
    qw(base64 quoted-printable 7bit 8bit binary none);
my $DefaultEncoding = 'base64';

# Recognized MIME types.
my %Types = (
	     htm   => 'text/html',
	     html  => 'text/html',
	     shtml => 'text/html',
	     ini   => 'text/plain',
	     txt   => 'text/plain',
	     gif   => 'image/gif',
	     jpg   => 'image/jpeg',
	     jpeg  => 'image/jpeg',
	     pdf   => 'application/pdf',
	     doc   => 'application/x-msword',
	     none  => 'none',
	    );
my %ValidType = map { ($_, 1) } values %Types;
my $DefaultType = 'text/plain';
my $DefaultFileType = 'application/octet-stream';

# End-of-line sequence used in constructing messages.
my $EOL = "\r\n";
my $Error;
my $BoundaryCounter = 0;

# ----------------------------------------------------------------------
#  sendAll
#
sub sendAll
  {
    return sendMail(@_);
  }

# ----------------------------------------------------------------------
#  sendEach
#
sub sendEach
  {
    my %cfg = parseNamedParams(@_);
    my (%list, $field, $addr, @errors);
    
    # Assemble the list of recipients, then delete the original
    # lists so that they don't appear in the headers.
    for (qw(to cc bcc)) {
      $list{$_} = getList($cfg{$_}) if $cfg{$_};
      delete $cfg{$_};
    }

    # This keeps track of which recipient field is used (such as "To" or "Cc").
    for $field (keys %list) {
      # Go through the list of recipients and send a message to each one.
      for $addr (@{ $list{$field} }) {
	$cfg{$field} = $addr;
      
	sendMail(\%cfg);

	# Accumulate error messages.
	push @errors, "$Error [Sending to $addr]" if $Error;
	delete $cfg{$field};
      }
    }
    $Error = join "\n", @errors;
  }

# ----------------------------------------------------------------------
#  sendMail
#
sub sendMail
  {
    my %cfg = parseNamedParams(@_);
    my ($sender, $code, $msg, @to);
    $Error = 0;
    
    # The "file" and "files" parameters are the same.
    push(@{$cfg{file}}, $cfg{files}) if $cfg{files};
    
    # Set default values as necessary.
    my $myHost = (gethostbyname('localhost'))[0] || 'localhost';
    my $myName = $ENV{USER} || 'sender';
    $cfg{from} ||= $Defs{from} || "$myHost\@$myName";
    $cfg{msg}    = $cfg{message} || $cfg{msg} ||
      $Defs{message} || $Defs{msg} || $EOL;
    $cfg{smtp} ||= $cfg{sendmail} || $cfg{cmd} || $cfg{mailer} || $Defs{smtp} ||
      $Defs{sendmail} || $Defs{cmd} || $Defs{mailer};
    
    # Make sure the subject line is just a single line (or things get messy).
    $cfg{subject} =~ s/[\n\r]+/ /sg;
    
    # Assemble the e-mail header, including date (because Exchange wont add one for us)
    my $now_string = localtime();
    my $header = join "",
    "From: $cfg{from}$EOL",
    "Subject: $cfg{subject}$EOL",
    "Date: $now_string$EOL",
    defined $cfg{to}  ? "To: "  . join(',', getList($cfg{to}))  . $EOL : '',
    defined $cfg{cc}  ? "Cc: "  . join(',', getList($cfg{cc}))  . $EOL : '',
    defined $cfg{bcc} ? "Bcc: " . join(',', getList($cfg{bcc})) . $EOL : '',
    ;
    
    # Generate a list of all the recipients.
    @to = getList($cfg{to}, $cfg{cc}, $cfg{bcc});

    # Keep values as defaults for next time.
    while (my ($k, $v) = each %cfg) {
      $Defs{$k} = $v unless defined $Defs{$k};
    }
    # Don't save these as defaults.
    delete @Defs{qw(to cc bcc)};
    
    # Create a multipart MIME document if there are files
    # to attach, or if the message type is not plain text.
    if ((ref $cfg{file} ? @{$cfg{file}} : $cfg{file})
	or ($cfg{type} && $cfg{type} =~ m=^(text/plain|none)$=)) {
      $msg = multipart($header, %cfg);
      return $Error unless $msg;
    }
    # If just plain text with no attachments, then keep it simple.
    else {
      $msg = $header . $EOL . $cfg{msg};
    }

    # Send the message.
    return $Error = sendMessage($cfg{smtp}, $msg, $cfg{from}, @to);
  }

# ----------------------------------------------------------------------
#  sendMessage
#
sub sendMessage
  { 
    my ($mailAgent, $message, $from, @to) = @_;
    
    return $Error = "${Pkg}::sendMessage: Empty message" unless $message;
    
    # Check for mail agent.
    if ($mailAgent) {
      # Program name must have full path or is assumed to be SMTP server.
      return $mailAgent =~ m=^/= ?
	sendMessageViaCmd($mailAgent, $message) :
	  sendMessageViaSmtp($mailAgent, $message, $from, @to);
    }
    
    # If mail agent not defined, then first try default sendmail
    # command, then try the default SMTP server(s).
    $Error = sendMessageViaCmd($SendmailCmd, $message);
    while ($Error and $_ = shift @SmtpServers) {
      $Error = sendMessageViaSmtp($_, $message, $from, @to);
    }
    
    $Error;
  }

# ----------------------------------------------------------------------
#  sendMessageViaCmd
#
sub sendMessageViaCmd
  {
    my ($command, $message) = @_;
    local (*FH);

    # This function only runs properly on Unix-like systems, so
    # strip out any carriage returns since these are unwelcome.
    $message =~ tr/\r//d;

    # Strip out any "dangerous" characters from command.
    $command =~ s=[|&;()]= =g;
    
    # Right now, this only handles properly formated 'sendmail' commands.
    open FH, "| $command" or return $Error =
      "${Pkg}::sendMessageViaCmd: Error running command ($command): $!";
    print FH $message; close FH;
    
    $Error = 0;
  }

# ----------------------------------------------------------------------
#  sendMessageViaSmtp
#
sub sendMessageViaSmtp
  {
    my ($server, $message, $from, @to) = @_;
    my ($resp);
    
    my $mailPort = 25;
    my $S = new IO::Socket::INET(PeerAddr => "$server:$mailPort")
      or return $Error = "${Pkg}::sendMessageViaSmtp: $@";
    
    # Just in case there's an SMTP end seqeuence in the text.
    # A single period on a line needs to have a second period to escape it.
    $message =~ s/^\./../mg;

    # Remove any BCC header lines.
    my ($head, $body) = split(/\r?\n\r?\n/, $message, 2);
    $head =~ s/[\r\n]*Bcc: [^\r\n]*//sig;
    $message = "$head${EOL}${EOL}$body";
    
    # Local hostname for HELO
    my $myHost = (split(/@/, $from))[1] ||
      (gethostbyname('localhost'))[0] || 'localhost';
    
    # Build the list of SMTP commands.
    my @cmds = ("HELO $myHost\r\n");
    push @cmds, "MAIL FROM:<$from>\r\n";
    push @cmds, map { "RCPT TO:<$_>\r\n" } getList(@to);
    push @cmds, "DATA\r\n";
    push @cmds, $message . "\r\n.\r\n";
    push @cmds, "QUIT\r\n";
    
    # Execute the list of SMTP commands.
    do {
      $resp = getSmtpResponse($S);
      if (!$resp or $resp =~ /^[45]/) {
	$S->close;
	$resp =~ tr/\r\n//d;
	return $Error = "${Pkg}::sendMessageViaSmtp: $resp";
      }
      
      print $S shift @cmds;
    } while (@cmds);
    
    # The response to the QUIT command is ignored.
    $resp = getSmtpResponse($S);
    $S->close;
    
    $Error = 0;
  }

# ----------------------------------------------------------------------
#  multipart
#
sub multipart
  {
    my ($header, %cfg) = @_;
    my ($file);
    
    my $type     = lc $cfg{type}     if $ValidType{lc $cfg{type}};
    my $filetype = lc $cfg{filetype} if $ValidType{lc $cfg{filetype}};
    my $encoding = lc $cfg{encoding} if $ValidEncoding{lc $cfg{encoding}};

    my $boundaryDef = mimeBoundary();

    # Two dashes added to boundary definition for boundary.
    my $boundary = "--$boundaryDef";
    
    # Create header for MIME message.
    $header = $header . "MIME-Version: 1.0$EOL" .
      "Content-Type: multipart/mixed; boundary=\"$boundaryDef\"$EOL";
    
    my @msg = ($header, "This is a multi-part message in MIME format...", "");

    $type ||= $DefaultType;
    
    # Assumption made that the message is well behaved.
    if ($cfg{msg}) {
      my $encoding = ($type =~ /text/ ? '7bit' : 'binary');
      push @msg, $boundary,
      "Content-Type: $type",
      "Content-Disposition: inline",
      "Content-Transfer-Encoding: $encoding",
      "",
      $cfg{msg},
      ;
    }
    
    # MIME-encode the attachemnts.
    for $file (getList($cfg{file})) {
      (my $name = $file) =~ s=.*/==;
      my $ftype = $filetype || guessFileType($file) || $DefaultFileType;
      my $etype = $encoding || ($ftype =~ /text/ ? '7bit' : $DefaultEncoding);

      my $data = encodeFile($file, $etype);
      return 0 unless $data;
      
      push @msg, "",
      $boundary,
      "Content-Type: $ftype; name=\"$name\"",
      "Content-Disposition: inline; filename=\"$name\"",
      "Content-Transfer-Encoding: $etype",
      "",
      $data,
      ;
    }
    # Last boundary marker (two dashes at end).
    push @msg, "${boundary}--$EOL" if $file;
    
    join $EOL, @msg;
  }

# ----------------------------------------------------------------------
#  guessFileType
#
sub guessFileType
  {
    my $suffix = (split /\./, shift)[$#_];
    $Types{$suffix} || $DefaultFileType;
  }

# ----------------------------------------------------------------------
#  getSmtpResponses
#
sub getSmtpResponse
  {
    my $s = shift;
    my $line = <$s>;
    my $response = '';
    
    # A dash after the code number indicates continuation.
    while ($line =~ s/^\d{3}-//) {
      $response .= $line;
      $line = <$s>;
    }
    $line =~ s/^(\d{3} )//;
    $response = $1 . $response . $line;
    
    return $response;
  }

# ----------------------------------------------------------------------
#  getList
#
sub getList
  {
    my @list = ();
    
    # Go through the arguments and unpack scalars and list references
    # into a single list.
    foreach (@_) {
      next unless defined;

      push(@list, getList(@$_)), next if ref eq 'ARRAY';
      push(@list, getList(%$_)), next if ref eq 'HASH';
      push(@list, split /\s*,\s*/), next if /,/;
      
      # Doesn't cover error cases.
      push @list, $_;
    }
    
    # Return either a list or a list reference as required.
    wantarray ? @list : \@list;
  }

# ----------------------------------------------------------------------
#  getScalar
#
sub getScalar
  {
    my ($value) = @_;
    ref $value eq 'ARRAY' ? $value : shift @$value;
  }

# ----------------------------------------------------------------------
#  parseNamedParams
#
sub parseNamedParams
  {
    my %cfg;
    
    while ($_ = shift) {
      push(@_, @$_),   next if ref eq 'ARRAY';
      push(@_, (%$_)), next if ref eq 'HASH';
      
      if ($ArrayParam{lc $_}) {
	push @{$cfg{lc $_}}, getList(shift);
      }
      else {
	$cfg{lc $_} = shift;
      }
    }
    
    %cfg;
  }

# ----------------------------------------------------------------------
#  encodeFile
#
sub encodeFile
  {
    my ($file, $encoding) = @_;
    my $chunkSize = 60*57; # Base64 chunk size
    my ($data, $buf); local(*FH);
    
    open FH, $file or
      ($Error = "${Pkg}::encodeFile: Error opening file ($file): $!", return 0);
    
    if ($encoding eq 'quoted-printable') {
      $data .= encodeQP($buf, $EOL) while read(FH, $buf, $chunkSize);
      close FH; return $data;
    }

    if ($encoding eq 'base64') {
      $data .= encodeBase64($buf, $EOL) while read(FH, $buf, $chunkSize);
      close FH; return $data;
    }

    # No encoding for these.
    if ($encoding =~ /^(none|[78]bit|binary)$/) {
      $data .= $buf while read(FH, $buf, $chunkSize);
      close FH; return $data;
    }

    $Error = "${Pkg}::encodeFile: Unknown encoding type ($encoding)", return 0;
  }

# ----------------------------------------------------------------------
#  encodeBase64
#
sub encodeBase64
  {
    my ($data, $eol) = @_;
    return '' unless $data;
    $eol = "\n" unless $eol;
    
    pos($data) = 0; # Reset 'match' pointer.
    my $coded = join '', map( pack('u',$_) =~ /^.(\S*)/, ($_[0]=~/(.{1,45})/gs));
    
    $coded =~ tr(\` -_)(AA-Za-z0-9+/);
    my $pad = (3 - length($data) % 3) % 3;
    $coded =~ s/.{$pad}$/'=' x $pad/e if $pad;
    $coded =~ s/(.{1,76})/$1$eol/g;
    
    $coded;
  }

# ----------------------------------------------------------------------
#  encodeQP
#
sub encodeQP
  {
    my ($string, $eol) = @_;
    my $rep = sub { sprintf('=%02x', ord($_[0])) };

    # Rules 2 & 3 (literal representation and white space)
    $string =~ s/([^ \t\n!-<>-~])/&$rep($1)/eg;

    # Rule 3 (encode whitespace at eol)
    $string =~ s/([ \t]+)$/ join('', map { &$rep($_) } split('', $1))/egm;

    # Rule 5 (Lines must be shorter than 76 chars. Do not break =XX codes.)
    my $shortlines = "";
    $shortlines .= "$1=$eol"
      while $string =~ s/(.*?^[^\n]{73} (?:
		 [^=\n]{2} (?! [^=\n]{0,1} $) # 75 not followed by .?\n
	        |[^=\n]    (?! [^=\n]{0,2} $) # 74 not followed by .?.?\n
		|          (?! [^=\n]{0,3} $) # 73 not followed by .?.?.?\n
		 ))//xsm;

    "$shortlines$string";
}

# ----------------------------------------------------------------------
#  mailerDefaults
#
sub mailerDefaults
  {
    %Defs = (), shift if $_[0] eq 'clear';
    %Defs = parseNamedParams(%Defs, @_);
  }

# ----------------------------------------------------------------------
#  mimeBoundary
#
sub mimeBoundary
  {
    "--------=_$$-" . scalar(time) . "-" . $BoundaryCounter++;
  }

# ----------------------------------------------------------------------
#  error
#
sub error
  {
    $Error;
  }

# Read in module defaults from configuration file, if any.
BEGIN {
  my $pkg = *{VERSION}{PACKAGE};
  my $mod; ($mod = $pkg) =~ s=::=/=;
  my $config = $INC{"$mod.pm"};
  $config =~ s/\.pm$/.config/;

  if (-f $config) {
    local (*FH); open FH, $config;
    my @data = <FH>; close FH;
    eval join '', @data;
    if ($@) {
      for (@INC) {
	$config = "$_/$config", last if -f "$_/$config";
      }
      die "There is an error in the $pkg configuration file:\n    $config\n\n" .
	"The reported error is: $@\n" .
	  "Please correct or remove this file.\n\n";
    }
  }
}

1;

__END__

