INTRODUCTION

This note describes how to run the Router Audit Tool (RAT)
on Windows systems.

INSTALLATION

See etc\INSTALL.WIN32.txt


RUNNING RAT PROGRAMS

RAT is written as a collection of command-line programs.  It does
not have a fancy GUI.  To run RAT, you must create a command window
(sometimes called a 'DOS box') and run the RAT programs.  RAT can be
installed in two ways: as Windows native executables (.exe files) or
as Perl scripts.  This file describes how to run RAT when using the
native executables. 

To run any RAT programs, you'll need to know the drive and pathname
where RAT was installed.  If you used the InstallShield installer and
took the default choices, then the programs will be in C:\CIS\RAT\bin.
You can put this directory onto your PATH:

	C:\routers> set PATH=C:\CIS\RAT\bin;%PATH%

The rest of this note assumes you have added RAT to your PATH 
in this way.

To run the rat program and see a list of its options,
you could type the following:

        C:\routers> rat --help


PREPARING TO USE RAT

Before you use RAT, you should use the ncat_config program to create
a rule file specific to your routers.  Ncat_config will ask you some
questions about your router configuration and optional security
policies; for more information see the file etc/LOCALIZE.txt and
cisco-ios-router-benchmark.pdf.

Here is how to run ncat_config:

        C:\routers> ncat_config
          ... lots of questions appear here ...

At any ncat_config question you can type '?' to get more information
about the question.  If you answer all the questions, you'll have
a local rule configuration that will allow you to check your 
specific routers with much more precision.  

GETTING ROUTER CONFIG FILES

RAT is designed to audit and report on your Cisco router configuration files,
providing output in HTML and ASCII text files.  RAT comes with a tool called
snarf that can automate the configuration download process, or you can
manually download the configuration files.  Some of the many ways
to download your router configuration files are shown below.  Note that
all the examples below assume that you have run ncat_config and created
a local rules file named "local.conf".

Method #1

Use the snarf capability of RAT to download your configuration files.
This is done with the -a flag:

        C:\routers> rat -a -u USERNAME -w VTYPASS -e ENABLEPASS -r local.conf 10.1.1.1
        snarfing 10.1.1.1...Using username USERNAME
        done.
        auditing 10.1.1.1...done.
        ncat_report: writing 10.1.1.1.ncat_fix.txt.
        ncat_report: writing 10.1.1.1.ncat_report.txt.
        ncat_report: writing 10.1.1.1.html.
        ncat_report: writing rules.html (cisco-ios-benchmark.html).
        ncat_report: writing all.ncat_fix.txt.
        ncat_report: writing all.ncat_report.txt.
        ncat_report: writing all.html.
	C:\routers>

If your router does not require a username, simply omit the -u options.
If your router does not require running "enable" to access privilege 15
options, use the --noenable option.


Method #2

Using a TFTP server on your Windows system, copy your router
configuration to your workstation then audit using RAT.

Step 1. Download and install a TFTP server for windows.
        Cisco makes a TFTP server for Windows available at
        http://www.cisco.com/cgi-bin/tablebuild.pl/tftp
        SolarWinds makes another TFTP server option for Windows,
        available for download at
        http://www.solarwinds.net/Tools/Free_tools/TFTP_Server/

Step 2. Start your TFTP server
        You may wish to set the download path to a directory off the
	root such as C:\TFTP-root.

Step 3. Copy your configuration files to the TFTP server
        Login to your router and run the following command in privileged mode:
        "copy running-config tftp"
        Provide the address of your TFTP server and a filename at the
	appropriate prompts.

Step 4. Run rat to audit your configuration file:

        The document doc\rat.html in your installation directory for
        rat describes all the options you can specify at the command
        line.  Many people will wish to use rat in the following
        fashion:

	C:\>cd \TFTP-root
        C:\TFTP-root> rat -r local.conf cisco-router-confg

        You can specify multiple configuration filenames at the
        command line if you wish to audit multiple configurations.


Method #3

Capture your configuration file through the logging option of your
telnet client.

Step 1. Connect to your router with Telnet or SSH, then go into 
        privileged mode with the "enable" command.
        (On Windows NT, you can use the Windows telnet program; on
	 Windows 2000/XP, you can use the Windows Hyperterminal
	 program.  The freely available TeraTerm utility is also
	 quite suitable.)

Step 2. On your router, turn off screen pagination by entering the
	command	"terminal length 0".

Step 3. Turn on the logging feature of your telnet program.  Capture
	the output to C:\TEMP\router-config.txt, for example.

Step 4. On your router, run the command "show running-config".

Step 5. Turn off the logging feature of your Telnet program.

Step 6. Edit your captured file to remove any junk characters
	or extract lines that happened to be captured.

Step 7. Run rat to audit your configuration file:

        The document doc\rat.html in your installation directory for
        rat describes all the options you can specify on the rat command
        line.  Many people will wish to use rat in the following
        fashion:

	C:\>cd \TEMP
        C:\TEMP> C:\CIS\RAT\bin\rat -r local.conf router-config.txt

        You can specify multiple configuration filenames at the
        command line if you wish to audit multiple configurations.


Method #4

There are several commercial tools available for downloading
configurations.  Purchase and use them at your own discretion.

Method #5

If you simply want to experiment with RAT, you could copy
some of the configuration files that are used to for 
RAT regression testing and use those.  Try something like

  cd \temp
  copy c:\cis\rat\distrib\t\pass12 SampleIOSConfig.txt
  rat SampleIOSConfig.txt
  .
  .
  .
  [open index.html in a web browser]


WARNING

TFTP is a HIGHLY INSECURE protocol.  It uses NO AUTHENTICATION, not
even clear-text passwords.  Use it AT YOUR OWN RISK.  If you do use
it, be sure to take precautions such as applying firewall rules or
router access control lists in front of the machines running the TFTP
server to ensure that only authorized devices (your routers) can
access the TFTP server.

MOVING FILES FROM WINDOWS TO UNIX/END OF LINE DIFFERENCES

You should be aware that there may be problems with files that
have been moved from Windows systems to Unix systems.  For instance,
if you download/save router configurations on a Windows system
and then copy it to a Unix system for checking, some of the rules
will fail.  This is because Unix and Windows use different characters
to mean "End Of Line" and some of the rules match on "End Of Line".

Send comments to rat-feedback@cisecurity.org.

$Id: README.WIN32.txt,v 3.0 2003/05/14 11:30:03 george Exp $
