# $Id: TaggedText.pm,v 3.0 2003/05/14 11:30:07 george Exp $

package NCAT::TaggedText;

=head1 NAME

NCAT::TaggedText - Support for tags in descriptive text in NCAT config files

=head1 SYNOPSIS

    use 'NCAT::TaggedText';

    # process tags to produce LaTeX output
    $texOutputText = processTags('LaTeX', $inputText);
    # process tags to produce web page HTML output
    $webOutputText = processTags('HTML', $inputText);
    # strip out tags to produce plain text output
    $asciiOutputText = processTags('plain', $inputText);

=head1 DESCRIPTION

    This module defines a general mechanism for processing
    text with embedded benchmark-specific tags.  The following
    tags are supported:

      o   <cmd>text</cmd>     "text" is a literal command
      o   <code>text</code>    "code" is a block of program-like text (fixed font, literal linebreaks)
      o   <param>text</param>   "text" is a config data item or variable IOS command argument
      o   <a href="URL">name</link>      Name is a link to URL
      o   <rscg>ref</rscg>     "ref" is a reference into the RSCG (e.g. "rscg.pdf#ref") 

=head1 AUTHOR

Neal Ziring

=cut

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

require Exporter;

# CVS commit log
#
# $Log: TaggedText.pm,v $
# Revision 3.0  2003/05/14 11:30:07  george
# Bring everthing up to at least 3.0
#
# Revision 1.2  2003/05/13 15:03:14  george
# Merge 2.0 into mainline
#
# Revision 1.1.2.10  2003/01/16 19:07:04  gmj
# * changed back to using "!" for substitute delimeter
#
# Revision 1.1.2.9  2003/01/11 19:03:35  gmj
# * Split results on "|", not "!".  "!" might conflict with IOS comments.
#
# Revision 1.1.2.8  2002/12/29 22:16:59  benchoff
# Changes for using TaggedText in ncat_bench.  Mostly working now.
#
# Revision 1.1.2.7  2002/12/29 22:06:25  benchoff
# More changes to get the LaTeX to work.  Cleaned up most of my mess
# from last commit.
#
# Revision 1.1.2.6  2002/12/29 15:31:37  benchoff
# Moved cleanLatex and cleanAlltt from ncat_bench to here.
# Renamed processTags to substututeTags and added new processTags.
# Renamed MasterTable to SubstitutionTable.
#
# Revision 1.1.2.5  2002/12/28 16:35:19  benchoff
# Change LaTeX commands in TaggedText.pm.
# Call processTags from ncat_bench for Action and Match items.
#
# Revision 1.1.2.4  2002/12/27 18:34:18  gmj
# * Added <code>...</code> psuedo tag
#
# Revision 1.1.2.3  2002/12/18 21:29:08  nziring
# Added <cite> tag.
#
# Revision 1.1.2.2  2002/12/11 17:06:49  nziring
# Fixed missing tail for module.
#
# Revision 1.1.2.1  2002/12/10 13:22:29  nziring
# Module to process <tag></tag> pairs in benchmark text
#
#
#

@ISA = qw(Exporter AutoLoader);

@NCAT::TaggedText::EXPORT = qw(
	   &processTags
       &cleanLatex
       &cleanAlltt
);

use vars qw(
       &processTags
       &cleanLatex
       &cleanAlltt
);

$VERSION = '0.1';

sub Version { $VERSION };

# Substitution table -
# This table shows the substitution that must
# occur for each tag.  The table is an array
# of arrays, each row of the array represents
# one kind of substitution to perform in the 
# text.  In each row vector, the 0th element
# is the pattern to match in the text.  Each
# subsequent element 1,2,3... is the substitution
# pattern for a particular format.
#    1  for  LaTeX output
#    2  for  HTML output
#    3  for  unformatted plain text output
# All matching is case-insensitive.
#
my @SubstitutionTable;
@SubstitutionTable = (
[ '<cmd>(.*?)</cmd>',    # base pattern for a literal command
  '\\\\BenchCmd{$1}',             # LaTeX result
  '<tt><b>$1</b></tt>',	 # HTML result
  '$1',			 # plain text result
],

[ '<code>(.*?)</code>',    # base pattern for a literal command
  '\\\\begin{BenchCodeEnv} $1 \\\\end{BenchCodeEnv}', # LaTeX result
  '<tt><pre>$1</pre></tt>',	 # HTML result
  '$1',			 # plain text result
],

[ '<param>(.*?)</param>',  # base pattern for a command parameter/variable
  '\\\\BenchParam{$1}',		   # LaTeX result
  '<i>$1</i>',		   # HTML result
  '$1',			   # plain text result
],

[ '<a\s+href="([^"]*)">(.*?)</a>',  # base pattern for a link
  '\\\\BenchLink{$2}{$1}',		    # LaTeX result
  '<a href="$1">$2</a>',	    # HTML result
  '$2 ($1)',			    # plain text result
],

[ '<rscg>page([0-9]+)</rscg>',      # base pattern for RSCG page reference
  'RSCG page  $1',		    # LaTeX result
  '<a href="rscg.pdf#Page$1">RSCG page $1</a>',	    # HTML result
  'RSCG page $1',		    # plain text result
],

[ '<rscg>(.*?)</rscg>',		    # base pattern for RSCG target reference
  'RSCG  $1',		            # LaTeX result
  '<a href="rscg.pdf#$1">RSCG $1</a>',	    # HTML result
  'RSCG $1',		            # plain text result
],

[ '<cite\s+ref="([^"]*)">(.*?)</cite>',  # base pattern for citation
  '\\\\cite{$1}',			 # LaTeX result
  '<i>$2</i>',                           # HTML result
  '"$2"',                                # plain text result
],

[ '<cite>(.*?)</cite>',                  # base pattern for bad citation
  '{\\\\it $1}',			 # LaTeX result
  '<i>$1</i>',                           # HTML result
  '"$1"',                                # plain text result
],

# if more tags are needed, put them here

# end of @SubstitutionTable
);

# Master Processing Table Column type map -
# the first argument to the processTags function is
# the type of tag processing needed.  This hash maps
# from the type string in lowercase into the column 
# of the SubstitutionTable to be used for the output
# substitution.
#
my %MasterTableColumnMap;
%MasterTableColumnMap = 
 ( 'latex' => 1, 'tex' => 1, '.tex' => 1, 
    'html' => 2, 'web' => 2, '.html' => 2,
    'plain' => 3,'text' => 3, 'ascii' => 3,
 );

# Substitute Tag function -
# this function handles tag processing in cases
# where it can be done by simple substitution.
# If the input text matches one of the patterns in
# SubstitutionTable, a substitution command is created
# from the expression for the tag and type and is eval'ed.
#
sub substituteTags {
    my ($ptypStr, $text) = @_;
    my ($ptyp, $result, $row, $pat, $sub, $expr);
    $result = $text;
    $ptyp = $MasterTableColumnMap{lc($ptypStr)};
    if ($ptyp) {
	for $row (@SubstitutionTable) {
	    $pat = $row->[0];
	    $sub = $row->[$ptyp];
	    if ($result =~ m/$pat/si) {
		$expr = '$result =~ s!' . $pat . '!' . $sub . '!gsi';
		eval($expr);
	    }
	}
    }
    return $result;
}

# cleanTaggedLatex
#
# Run cleanLatex() on a string without changing the tags.
#
sub cleanTaggedLatex {
    my ($inStr) = @_;
    my ($text,$tag,$matched);

    my $rest = "";
    my $outStr = "";

    #print "In: $inStr\n";

    while ( $inStr ) {

      # Split $inStr as follows:
      #     $text - text before the first tag
      #      $tag - the first tag
      #  $matched - text up to and including the first tag, null if
      #             there was no tag.
      #     $rest - text after the first tag or the whole string if no tag
      #             was found.
      # 
      ($matched,$text,$tag,$rest) = ( $inStr =~ m!(([^<]*)(</?[^>]+>))?(.*)!s );

      if ( $matched ) {
        # There was at least one tag

        if ( $text ) {
          # There was text before the tag.
          $outStr .= cleanLatex($text);
        }

        $outStr .= $tag;

	    $inStr = $rest;

      } else {
        # No tag found.  Process what's left.
        if ( $rest ) {
            $outStr .= cleanLatex($rest);
        }
        last;
      }
    }
    return $outStr;
}

#########################################################################
# Exported subroutines
#########################################################################
#
# cleanAlltt(string)
#
# Escape special characters in a string to be included in a LaTeX \alltt
# environment.
#
# Argument: string to be processed
#
# Return:   input string with appripriate substitutions.
#
sub cleanAlltt {

  my $latex_str = shift;

  # Remove any \x7f (which should not be in the string anyway).
  $latex_str =~ s/\x7f//g;

  # Convert \ to \x7f temporarily since most of the other substitutions
  # end up adding \.
  $latex_str =~ s/\\/\x7f/g;

  # Special characters \ { and } get put inside of \verb
  $latex_str =~ s/{/\\verb!{!/g;
  $latex_str =~ s/}/\\verb!}!/g;

  # \x7f is converted to \verb!\!
  $latex_str =~ s/\x7f/\\verb!\\!/g;

  return $latex_str;

}

#
# cleanLatex(string)
#
# Escape special characters in a string to be included in a LaTeX file.
#
# Argument: string to be processed
#
# Return:   input string with appripriate substitutions.
#
sub cleanLatex {

  my $latex_str = shift;

  # Remove any \x7f (which should not be in the string anyway).
  $latex_str =~ s/\x7f//g;

  # Convert \ to \x7f temporarily since most of the other substitutions
  # end up adding \.
  $latex_str =~ s/\\/\x7f/g;

  # Special characters # $ % & _ { } get prefixed with a \
  $latex_str =~ s/#/\\#/g;
  $latex_str =~ s/\$/\\\$/g;
  $latex_str =~ s/%/\\%/g;
  $latex_str =~ s/&/\\&/g;
  $latex_str =~ s/_/\\_/g;
  $latex_str =~ s/{/\\{/g;
  $latex_str =~ s/}/\\}/g;

  # ~ ^ and \ get special handling
  $latex_str =~ s/~/\\~{}/g;
  $latex_str =~ s/\^/\\^{}/g;

  # \x7f is converted to $\backslash$
  $latex_str =~ s/\x7f/\$\\backslash\$/g;

  return $latex_str;

}


# Process Tag function -
# this function handles tag processing in
# some benchmark text.  Generally, any descriptive
# text in the benchmark should be run through this
# function.  This function expects to be called in
# scalar context only, with two arguments: the
# processing type (string) and the text to be
# processed (string).  The result will be the second
# argument with appropriate processing performed,
# as long as the first argument is a valid type in
# the MasterTableColumnMap.  Otherwise the second
# argument is returned untouched.
# 
sub processTags {
    my ($ptypStr, $text) = @_;
    my ($ptyp);

    my $result = $text;

    $ptyp = $MasterTableColumnMap{lc($ptypStr)};

    if ( $ptyp ) {
      if ( $ptyp == $MasterTableColumnMap{latex} ) {
        $result = substituteTags($ptypStr,cleanTaggedLatex($text));
      } elsif ( $ptyp == $MasterTableColumnMap{html} ) {
        $result = substituteTags($ptypStr,$text);
      } elsif ( $ptyp == $MasterTableColumnMap{text} ) {
        $result = substituteTags($ptypStr,$text);
      } else {
        # This type is defined in MasterTableColumnMap, but not handled.
        die "processTags(): type \"$ptypStr\" defined but not handled.\n";
      }
    }

    return $result;
}


1;

__END__
