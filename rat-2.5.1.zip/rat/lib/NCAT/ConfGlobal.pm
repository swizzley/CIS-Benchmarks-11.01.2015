package NCAT::ConfGlobal;
use strict;
use base 'NCAT::ConfObj';

# hide pseudo-hash warning in 5.8
no warnings 'deprecated';

=head1 NAME

NCAT::ConfClass - Class that implements NCAT class element type

=head1 SYNOPSIS

  use 'NCAT::ConfClass';

  # create new object

  $element = new NCAT::ConfClass(name=>"ExternalIF",
			      description=>"Service Checks",
			      parent=>"Default Checks",
			      selected=1
			      );

  # Unique (non-inherited) field names/purpose
  #
  #   None.  This class is a synonym for ConfObj.


  # get/set methods are defined for all fields

  # debugging/diagnostic

  $element->dump;

=head1 DESCRIPTION

  This module defines the datatype for NCAT class elements.
  Class elements are derived from the basic ConfObj datatype
  and have no additional fields or methods.
  

=head1 AUTHOR

George M. Jones

=head1 SEE ALSO

NCAT::ConfGlobal

=cut

#
# $Log: ConfGlobal.pm,v $
# Revision 3.0.6.1  2004/05/11 20:06:24  nziring
# Disabled warnings about deprecated Perl features.
#
# Revision 3.0  2003/05/14 11:30:06  george
# Bring everthing up to at least 3.0
#
# Revision 1.2  2003/05/13 15:03:14  george
# Merge 2.0 into mainline
#
# Revision 1.1.2.3  2002/12/24 15:07:16  gmj
# * Added value method
#
# Revision 1.1.2.2  2002/11/09 15:38:30  gmj
# * added dump routine
#
# Revision 1.1.2.1  2002/10/11 12:54:13  gmj
# * Development update
#
# Revision 1.1.2.1  2002/10/08 15:21:30  gmj
# * development snapshot
#
# Revision 1.1.2.3  2002/10/04 11:16:28  gmj
# * development snapshot
#
#

use fields qw(value);

sub new {
  my $class = shift;
  my $self = fields::new($class);

  # set defaults

  $self->{value} = undef;

  # call base class constructor

  $self->SUPER::new(@_);

  return $self;
}

sub value {
  my NCAT::ConfGlobal $self = shift;
  $self->{value} = shift if @_;
  return $self->{value};
}


sub dump {
  my NCAT::ConfGlobal $self = shift;
  my $prefix = shift;
  my $fh = shift;

  $self->dump_line ($fh,"$self->{name}:$self->{value}\n")
    if (defined $self->{name} and defined $self->{value}
       and not $self->{value} =~ /^\s*$/);

#  $self->SUPER::dump($prefix,$fh);
  print $fh "\n";
}


1;
