package NCAT::ConfClass;
use strict;
use base 'NCAT::ConfObj';

# hide pseudo-hash warning in 5.8
no warnings 'deprecated';


=head1 NAME

NCAT::ConfClass - Class that implements NCAT class element type

=head1 SYNOPSIS

  use 'NCAT::ConfClass';

  # create new object

  $element = new NCAT::ConfClass(name=>"ExternalIF",
			      description=>"Service Checks",
			      parent=>"Default Checks",
			      selected="yes"
			      );

  # Unique (non-inherited) field names/purpose
  #
  #   None.  This class is a synonym for ConfObj.


  # get/set methods are defined for all fields

  # debugging/diagnostic

  $element->dump;

=head1 DESCRIPTION

  This module defines the datatype for NCAT class elements.
  Class elements are derived from the basic ConfObj datatype
  and have no additional fields or methods.
  

=head1 AUTHOR

George M. Jones

=head1 SEE ALSO

NCAT::ConfObj

=cut

#
# $Log: ConfClass.pm,v $
# Revision 3.0.6.1  2004/05/11 20:06:24  nziring
# Disabled warnings about deprecated Perl features.
#
# Revision 3.0  2003/05/14 11:30:06  george
# Bring everthing up to at least 3.0
#
# Revision 1.2  2003/05/13 15:03:14  george
# Merge 2.0 into mainline
#
# Revision 1.1.2.5  2002/12/24 14:49:58  gmj
# * Added the ability to skip a rule during parse
#
# Revision 1.1.2.4  2002/11/17 17:02:37  gmj
# * selected attribute is now yes/no
#
# Revision 1.1.2.3  2002/11/09 15:33:16  gmj
# * Updated dump routine to print out either heirarcy or parsable config
#
# Revision 1.1.2.2  2002/10/28 14:41:56  gmj
# * development snapshot
#
# Revision 1.1.2.1  2002/10/08 15:21:30  gmj
# * development snapshot
#
# Revision 1.1.2.3  2002/10/04 11:16:28  gmj
# * development snapshot
#
#

use fields qw(value defaultvalue);

sub new {
  my $class = shift;
  my $self = fields::new($class);

  # set defaults

  # call base class constructor

  $self->SUPER::new(@_);

  return $self;
}



#
# Deselect classes
#

sub deselect {
  my NCAT::ConfObj $self = shift;

print "Deselect\n";

  $self->walk_tree(0,999,\&deselect_classes);
  return 1;
}

sub deselect_classes {
  my $self = shift;

  if ($self->isa("NCAT::ConfClass")) {
    $self->selected("no");
    print "DESELECT: /$self->{name}/\n";
  }
  

}

sub dump {
  my NCAT::ConfClass $self = shift;
  my $prefix = shift;
  my $fh = shift;

  $self->SUPER::dump($prefix,$fh);
  print $fh "\n";
}


1;
