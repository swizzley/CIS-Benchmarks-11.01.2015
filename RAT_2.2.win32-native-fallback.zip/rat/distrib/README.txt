This file describes things you might want to know about
the Router Audit Tool (rat).  rat is a free tool for
checking the configuration of Cisco routers and PIX
firewalls, and similar files.

INSTALL-AND-GO

  See etc/INSTALL.txt for quick-start instructions.

FOR MORE USEFUL READING

  See the doc/ directory.  It contains documentation
  for each program that is a part of the router
  audit tool in text, html and man formats.

RELEASE FILES

  The files in the tar file for this release are:


  Programs:

    rat-2.2/bin
    rat-2.2/bin/snarf.PL
    rat-2.2/bin/ncat.PL
    rat-2.2/bin/rat.PL
    rat-2.2/bin/ncat_bench.PL
    rat-2.2/bin/ncat_config.PL
    rat-2.2/bin/ncat_report.PL
    rat-2.2/doc

  Documentation:

    rat-2.2/doc/NCAT::Conf.3pm
    rat-2.2/doc/NCAT::ConfClass.3pm
    rat-2.2/doc/NCAT::ConfData.3pm
    rat-2.2/doc/NCAT::ConfGlobal.3pm
    rat-2.2/doc/NCAT::ConfObj.3pm
    rat-2.2/doc/NCAT::ConfRule.3pm
    rat-2.2/doc/NCAT::Mailer.3pm
    rat-2.2/doc/NCAT::TaggedText.3pm
    rat-2.2/doc/ncat.1
    rat-2.2/doc/ncat.html
    rat-2.2/doc/ncat.txt
    rat-2.2/doc/ncat_report.1
    rat-2.2/doc/ncat_report.html
    rat-2.2/doc/ncat_report.txt
    rat-2.2/doc/rat-logo-try1.gif
    rat-2.2/doc/rat-splash-3.bmp
    rat-2.2/doc/rat-splash-try3.eps
    rat-2.2/doc/rat-splash-try3.tif
    rat-2.2/doc/rat.1
    rat-2.2/doc/rat.html
    rat-2.2/doc/rat.txt
    rat-2.2/doc/snarf.1
    rat-2.2/doc/snarf.html
    rat-2.2/doc/snarf.txt

  General Release Information:

    rat-2.2/ChangeLog.txt
    rat-2.2/README.txt
    rat-2.2/install.bat

  Makefiles

    rat-2.2/Makefile-nosnarf.PL
    rat-2.2/Makefile.PL
    rat-2.2/winmake-nosnarf.PL
    rat-2.2/winmake.PL

  Benchmarks and Questionnaires:

    rat-2.2/cisco-ios-router-benchmark.pdf
    rat-2.2/cisco-ios-router-questionnaire.pdf
    rat-2.2/cisco-pix-benchmark.pdf
    rat-2.2/cisco-pix-questionnaire.pdf
    
  The NSA Guide

    rat-2.2/rscg.pdf

  Contributed/Extra files

    rat-2.2/contrib
    rat-2.2/contrib/code
    rat-2.2/contrib/code/IOSsanitizer.pl
    rat-2.2/contrib/doc
    rat-2.2/contrib/doc/rule-callouts.pod
    rat-2.2/contrib/proposals
    rat-2.2/contrib/proposals/ConfigFileProposal.txt
    rat-2.2/contrib/proposals/Rat1.2-Callout-Design.html
    rat-2.2/contrib/proposals/Rat1.2-email_notification-Proposal.html

  ncat/rat configuration files for Cisco IOS

    rat-2.2/etc
    rat-2.2/etc/configs
    rat-2.2/etc/configs/cisco-ios
    rat-2.2/etc/configs/cisco-ios/cis-level-1.conf
    rat-2.2/etc/configs/cisco-ios/cis-level-2.conf
    rat-2.2/etc/configs/cisco-ios/common.conf
    rat-2.2/etc/configs/cisco-ios/contexts.txt
    rat-2.2/etc/configs/cisco-ios/fields.txt
    rat-2.2/etc/configs/cisco-pix
    rat-2.2/etc/configs/cisco-pix/cis-level-1.conf
    rat-2.2/etc/configs/cisco-pix/cis-level-2.conf
    rat-2.2/etc/configs/cisco-pix/common.conf
    rat-2.2/etc/configs/cisco-pix/contexts.txt
    rat-2.2/etc/configs/cisco-pix/fields.txt

  More General Release Info

    rat-2.2/etc/CIS_TERMS.txt
    rat-2.2/etc/FAQ.txt
    rat-2.2/etc/INSTALL.WIN32.txt
    rat-2.2/etc/INSTALL.txt
    rat-2.2/etc/INSTALL.unix.txt
    rat-2.2/etc/LICENSING.txt
    rat-2.2/etc/LOCALIZE.txt
    rat-2.2/etc/NSA_NOTICE.txt
    rat-2.2/etc/README.WIN32.txt
    rat-2.2/etc/README.PIX.txt
    rat-2.2/etc/RELEASE-NOTES.txt
    rat-2.2/etc/WISHLIST.txt

  Benchmark Source Files

    rat-2.2/etc/tex
    rat-2.2/etc/tex/Makefile.benchmark
    rat-2.2/etc/tex/README
    rat-2.2/etc/tex/bench-common.tex
    rat-2.2/etc/tex/bench.tex
    rat-2.2/etc/tex/questionnaire.tex

  ncat/rat perl modules

    rat-2.2/lib
    rat-2.2/lib/NCAT
    rat-2.2/lib/NCAT/ConfClass.pm
    rat-2.2/lib/NCAT/Conf.pm
    rat-2.2/lib/NCAT/ConfData.pm
    rat-2.2/lib/NCAT/ConfGlobal.pm
    rat-2.2/lib/NCAT/ConfObj.pm
    rat-2.2/lib/NCAT/ConfRule.pm
    rat-2.2/lib/NCAT/IOSCallouts.pm
    rat-2.2/lib/NCAT/IOSTest.pm
    rat-2.2/lib/NCAT/Mailer.pm
    rat-2.2/lib/NCAT/TaggedText.pm
    rat-2.2/lib/NCAT.pm

  ncat/rat test files

    rat-2.2/t
    rat-2.2/t/ncat.conf
    rat-2.2/t/fail11
    rat-2.2/t/fail12
    rat-2.2/t/ncat1.conf
    rat-2.2/t/pass12
    rat-2.2/t/pass12-level1
    rat-2.2/t/placeholder.t
    rat-2.2/t/test.t

HOW YOU CAN HELP

  See WISHLIST.txt

AUTHOR

  George M. Jones

MAJOR CONTRIBUTORS

  See Rat documentation.

FEEDBACK 

  Please send bugs/feedback to 

    rat-feedback@cisecurity.org

$Id: README.txt,v 3.0.6.1 2004/05/24 17:18:59 nziring Exp $
