INTRODUCTION

This note covers some considerations for running RAT against
Cisco PIX, ASA, and FWSM firewall devices.

INSTALLATION

There is nothing special you need to do during installation.
By default, both the IOS router benchmark rules and PIX, ASA, and FWSM firewall
benchmark rules will be installed.


RUNNING RAT PROGRAMS

The components of RAT are all command-line programs.  To run RAT,
you must create a terminal window or command window, and run the
commands from there.  RAT's final output includes HTML files,
which you can view with any modern web browser.

The usual sequence of steps for checking a device against the
CIS benchmark is:

	1. Tailor the benchmark to local security policy and
	   network configuration.  [using ncat_config]

	2. Acquire a copy of the PIX, ASA, or FWSM device configuration.

	3. Check the configuration against the tailored
	   benchmark.  [using rat]

	4. Examine the results.  [using a web browser]

Step one is easy, once you have installed the RAT package.
simply run ncat_config and answer the questions.  The very
first question allow you to select the benchmark to use,
type "cisco-firewall" to use the CIS PIX, ASA, and FWSM benchmark.  You can also
use the -s option to save a copy of the tailored benchmark
locally.

      $ ncat_config -s local-firewall.conf 
      ncat_config: Select configuration type [cisco-ios] ? cisco-firewall
       .
        .
         .
      $ 

Step two is up to you.  The RAT "snarf" utility was not designed to
acquire configurations from PIX, ASA, and FWSM firewalls, although it might work in
some cases.  See README.WIN32.txt for more ideas on downloading
configuration files.

Step three is the only tricky part.  In order for the rat command to
work correctly, you may have to supply the -t option, as shown in
the example below.  You must also supply the name of the local
tailored benchmark file, if any, and the names of configuration
files to check.

      $ rat -t cisco-firewall -r local-firewall.conf  border-firewall-1.dat
      auditing border-firewall-1.dat...
      Parsing: /local-firewall.conf/
       .
        .
         .
      ncat_report: writing all.html.
      $ 

In step four, just start up your favorite web browser and open the
file "all.html".  

$Id: $
