#!/usr/local/bin/perl

#JARED ALLISON
#April 23, 2002
#
#WARNING
#THE AUTHOR MAKES NO GUARANTEE, EXPRESS OR IMPLIED, ABOUT THIS SOFTWARE.  IT
#MAY OR MAY NOT WORK CORRECTLY; THE AUTHOR ASSUMES NO LIABILITY FOR ITS USE.
#
# Copyright (C) 2002  Jared Allison <jallison@uu.net>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
  
#THE PURPOSE OF THIS SCRIPT IS TO SANITIZE A CISCO IOS CONFIG BY STRIPPING
#OUT ALL THE PASSWORDS AND MANGLING THE IP ADDRESSES, ETC.

#THIS IS NOT A COMPLETE MANGLER, BUT ATTEMPTS TO BE.  A KNOWN POTENTIAL PROBLEM
#IS THAT OF ACCIDENTALLY OBSCURING NETMASKS THAT ARE NOT CIDR BLOCKS

use strict;
use Getopt::Long;
use Data::Dumper;

my( $opt_a, $opt_h, $opt_v, $opt_p, $usage, @numericTrans, $result );

$usage=<<END;
Usage: $0 [-noversion|-v] [-noacl|-a] [-help|-h] [-paranoid|-p] [<file>]

  -noversion,-v  Causes the version line of the output file to be scrambled.
  -noacl,-a      Prevents access-list statements from being displayed.
  -paranoid,-p   Randomizes all of the IP addresses instead of just using 10 as
                 the first octet.
  -help,-h       Displays this message.

The author makes no guarantee, express or implied, about this software.  It
may or may not work correctly; the author assumes no liability for its use.
END

GetOptions(
	   "noversion|v" => \$opt_v,
	   "noacl|a" => \$opt_a,
	   "help|h" => \$opt_h,
	   "paranoid|p" => \$opt_p
	  );

die $usage if( $opt_h );

main();
################################################################################
sub main {
  my( $original, $clean, @time );

  if( defined($ARGV[0]) ) {
    #IF A FILE WAS GIVEN, TRY TO OPEN IT
    unless( open(CONFIG, $ARGV[0]) ) {
      die( "$0: Couldn't open '$ARGV[0]'\n" );
    }
    @{$original}=<CONFIG>;
    close( CONFIG );
  } else {
    #JUST USE STDIN
    @{$original} = <STDIN>;
  }
  fillNumericTranslations();
  $clean = sanitize( $original );
  print( "! sanitized by $0\n" );
  @time = gmtime( time() );
  print( "! run: ",$time[5]+1900,"-",$time[4]+1,
	 "-$time[3] $time[2]:$time[1]:$time[0]\n" );
  print( @{$clean} );
}
################################################################################
#FILL UP A TRANSLATION TABLE SO THAT EACH NUMBER BETWEEN 1 AND 254 INCLUSIVE
#WILL CORRESPOND TO ANOTHER UNIQUE RANDOM NUMBER BETWEEN 1 AND 254.  THE
#TRANSLATION TABLE IS KEPT AS A GLOBAL (UGH, I KNOW) VARIABLE JUST TO KEEP FROM
#PASSING THE ARRAY AROUND EVERYWHERE.
sub fillNumericTranslations {
  my( @numbersused, $randomNum, $numleft );

  $numericTrans[0] = 0;
  $numericTrans[255] = 255;
  foreach (1..245) {
    while(1) {
      $randomNum = int(rand(253))+1;
      if( $numbersused[$randomNum] != 1 ) {
	$numbersused[$randomNum] = 1;
	last;
      }
    }
    $numericTrans[$_] = $randomNum;
  }
  #JUST FILL IN THE LAST FEW
  foreach $numleft (246..254) {
    foreach (1..254) {
      if( $numbersused[$_] != 1 ) {
	$numbersused[$_] = 1;
	$numericTrans[$numleft] = $_;
	last;
      }
    }
  }
}
################################################################################
#THE MAIN CLEANING FUNCTION; GIVE IT A REFERENCE TO AN ARRAY THAT CONTAINS A
#CISCO CONFIG AND IT WILL RETURN A REFERENCE TO AN ARRAY THAT CONTAINS THE
#SANITIZED CONFIG.
sub sanitize {
  my $lines = $_[0];
  my( $translations, $line, $cleaned);
  $translations = {};

  while( @{$lines} ) {
    $line = shift @{$lines};
    chomp( $line );
    if( $line =~ /^\s/ ) {
      #SPECIAL CASE - THESE SECTIONS MUST BE CHECKED AS A WHOLE, PUSH IT BACK
      #ON SO THAT IT CAN BE CHECKED IN THE WHILE LOOP
      unshift( @{$lines}, $line );
      #WHILE THE NEXT LINE IS PART OF THIS SECTION, KEEP GOING
      while( $$lines[0] =~ /^\s/ ) {
        $line=shift @{$lines};
	chomp( $line );
	$line = transIPline( $line, $translations );
	if( $line =~ /(.*)description (.*)/ ) {
	  push( @{$cleaned}, " $1" . "description insert-description-here\n" );
	} elsif( $line =~ /^(access\-class \S+) (.*)/ ) {
	  push( @{$cleaned}, " ". translate( $1, $translations ) . " $2\n" )
	    unless($opt_a);
	} elsif( $line =~ /^ip (access\-group \S+) (.*)/ ) {
	  push( @{$cleaned}, " ip ". translate( $1, $translations ) . " $2\n" )
	    unless($opt_a);
	} elsif( $line =~ /(match ip address \S+)/ ) {
	  push( @{$cleaned}, " " . translate( $1, $translations ) . "\n" );
	} elsif( $line =~ /set community (\S+)/ ) {
	  push( @{$cleaned}, " set community " .
		translate( $1, $translations ) . "\n" );
	} elsif($line =~ /ip ospf message-digest-key (\d+) (md5(?: \d+)? \S+)/){
	  push( @{$cleaned}, " ip ospf message-digest-key $1 " .
		translate( $2, $translations ) . "\n" );
	} elsif( $line =~ /neighbor (\S+) remote-as (\d+)/ ) {
	  push( @{$cleaned}, " neighbor $1 remote-as " .
		translate( $2, $translations ) . "\n" );
	} elsif( $line =~ /password (\d+) (\S+)/ ) {
	  push( @{$cleaned}, " password $1 " . translate( $2, $translations ) .
		"\n" );
	} else {
	  push( @{$cleaned}, " $line\n" );
	}
      }
    } elsif( $line =~ /banner ?(exec|motd|login|incoming)? (\S)(\S)/ ) {
      #ANOTHER SPECIAL CASE - THE BANNER
      #THIS NEXT LINE TAKES TWO CHARACTERS IF THE FIRST WAS A CIRCUMFLEX,
      #OTHERWISE JUST ONE.  PROBLEM IS THAT A CTRL-C SHOWS UP AS A TWO-CHARACTER
      #'^C' STRING SOMETIMES
      my $delim = ($2 ne '^' ? $2 : $2.$3);
      $line = shift @{$lines};
      chomp( $line );
      while( defined($line) && $line !~ /\Q$delim\E$/ ) {
	$line = shift @{$lines};
	chomp( $line );
      }
      push( @{$cleaned}, "banner $1 $delim"."insert banner here" . "$delim\n" );
    } else {
      #NOMINAL CASE
      $line = transIPline( $line, $translations );
      if( $line =~ /^(access\-list \S+) (.*)/ ) {
	push( @{$cleaned}, translate( $1, $translations ) . " $2\n" )
	  unless( $opt_a );
	
      } elsif( $line =~ /ip access\-list (standard|extended) (\S+)/ ) {
	push( @{$cleaned}, "ip access-list $1 ".translate( $2, $translations ).
	      "\n" ) unless( $opt_a );
	
      } elsif( $line =~ /^\s*remark/ ) {
	push( @{$cleaned}, "remark insert-comment-here\n" );
	
      } elsif( $line =~ /^! (\S+)/ ) {
	push( @{$cleaned}, "! insert-comment-here\n" );
	
      } elsif( $line =~ /ip domain\-name (\S+)/ ) {
	push( @{$cleaned}, "ip domain-name router.domain.name\n" );
	
      } elsif( $line =~ /ip domain-list (\S+)/ ) {
	push( @{$cleaned}, "ip domain-list domain.here\n" );
	
      } elsif( $line =~ /ip ftp username (\S+)/ ) {
	push( @{$cleaned}, "ip ftp username ". translate( $1, $translations )
	     . "\n");
	
      } elsif ( $line =~ /username (\S+) password (\S+)/ ) {
	push( @{$cleaned}, "username ". translate( $1, $translations ) .
	      " password ". translate( $2, $translations ) . "\n" );
	
      } elsif( $line =~ /version (\S+)/ && $opt_v ) {
	push( @{$cleaned}, "version " . translate( $1, $translations ) . "\n" );
	
      } elsif( $line =~ /snmp\-server community (\S+)( view \s+)?( RO|RW|ro|rw)?\s?(\d+)?/ ) {
	push( @{$cleaned}, "snmp-server community " .
	      translate( $1, $translations ) . $2 . $3 .
	      (defined($4) ? " $translations->{acl}{$4}" : "" ) . "\n" );
	
      } elsif( $line =~ /(enable (?:password|secret)(?: level \d+)? \d+ )(\S+)/ ){
	push( @{$cleaned},  "$1" . translate( $2, $translations ) . "\n" );
	
      } elsif( $line =~ /password (\S+)/ ) {
	push( @{$cleaned}, "password " . translate( $1, $translations ) . "\n");
	
      } elsif( $line =~ /snmp\-server host \S+ (\S+)(.*)/ ) {
	push( @{$cleaned}, "snmp-server host " .
	      translate( $1, $translations ) . "$2\n" );

      } elsif( $line =~ /snmp\-server location \S.*/ ) {
	push( @{$cleaned}, "snmp-server location someplace, earth\n" );

      } elsif( $line =~ /snmp\-server contact \S.*/ ) {
	push( @{$cleaned}, "snmp-server contact foo\@bar.baz\n" );

      } elsif( $line =~ /^hostname (\S+)/ ) {
	push( @{$cleaned}, "hostname router.host.name\n" );
	
      } elsif( $line =~ /^ip host \S+ (.*)/ ) {
	push( @{$cleaned}, "ip host host.name $2\n" );

      } elsif( $line =~ /^ip community-list (\d+) (deny|permit) (\S+)/ ) {
	push( @{$cleaned}, "ip community-list $1 $2 ".
	      translate( $3, $translations ). "\n" );
	
      } elsif( $line =~ /^boot bootldr \S+/ ) {
	push( @{$cleaned}, "boot bootldr file-url\n" );
	
      } elsif( $line =~ /^boot system (flash|mop|rom|rcp|tftp|ftp|\S+)/ ){
	my $temp = $1;
	if( $temp =~ /(flash|mop|rcp|tftp|ftp|rom)/ ) {
	  push( @{$cleaned}, "boot system $1 file-url\n" );
	} else {
	  push( @{$cleaned}, "boot system file-url\n" );
	}
	
      } else {
	chomp( $line );
	push( @{$cleaned}, "$line\n" );
      }
    }
  }
  return $cleaned;
}
################################################################################
#GIVEN A SINGLE LINE OF TEXT, THIS FUNCTION WILL TRANSLATE ALL THE IP ADDRESSES
#(AND ANYTHING THAT LOOKS LIKE AN IP ADDRESS) EXCEPT FOR CIDR NETMASKS.
sub transIPline {
  my $line = $_[0];
  my $translations = $_[1];
  my $translatedLine = "";
  my @linePieces = split( / /, $line );
  my $piece;

  while( defined($piece=shift(@linePieces)) ) {
    if( $piece =~ /(\d+\.\d+\.\d+\.\d+)(\S*)/ ) {
      if( isNetMask( $1 ) ) {
	$translatedLine .= " $piece";
      } else {
	$translatedLine .= " " . translate( $1, $translations ) . "$2";
      }
    } else {
      $translatedLine .= " " if( $translatedLine ne '' );
      $translatedLine .= "$piece";
    }
  }

  return $translatedLine;
}
################################################################################
#GIVEN AN IP ADDRESS, RETURN 1 IF IT IS A CIDR BLOCK IN EITHER NORMAL OR REVERSE
#NOTATION, ZERO OTHERWISE.  IE 255.255.0.0=>1, 0.0.255.255=>1, 255.255.4.3=>0
sub isNetMask {
  #THIS ACTUALLY ONLY LOOKS FOR CIDR MASKS
  my $address = $_[0];
  my( $numericIP, $isMask );

  $isMask = 0;
  $numericIP = unpack( "N", pack( "C4", split( /\./, $address ) ) );
  #ALSO CHECK FOR CISCO 0.0.255.255 NOTATION
  foreach (0..32) {
    if( ($numericIP == (2**32-2**$_)) || ($numericIP == (2**$_)-1) ) {
      $isMask = 1;
      last;
    }
  }
  
  return $isMask;
}
################################################################################
#TRANSLATE A GIVEN STRING INTO THE APPROPRIATE GIBBERISH, BUT KEEP TRACK OF IT
#SO THAT A GIVEN STRING IS ALWAYS TRANSLATED THE SAME WAY
sub translate {
  my $rawText = $_[0];
  my $translations = $_[1];
  my( $translatedText, $acl );

  if( !defined($rawText) || $rawText eq '' ) {
    #IF FED UNDEF OR EMPTY STRING, JUST RETURN EMPTY STRING
    $translatedText = '';
  } elsif( defined($translations->{raw}{$rawText}) ) {
    $translatedText = $translations->{raw}{$rawText};
  } else {
    if( $rawText =~ /(\d+)\.(\d+)\.(\d+)\.(\d+)/ ) {
      #RAW IS AN IP - CHANGE TO PRIVATE SPACE
      if( $opt_p ) {
	$translations->{raw}{$rawText} = "$numericTrans[$1].$numericTrans[$2].".
	  "$numericTrans[$3].$numericTrans[$4]";
      } else {
	$translations->{raw}{$rawText} = "10.$2.$3.$4";
      }
      $translatedText = $translations->{raw}{$rawText};
    } elsif( $rawText =~ /(access-list|access\-group|access-class|match ip address) (\d+)/ ) {
      if( defined($translations->{acl}{$2}) ) {
	#ALREADY CREATED A MAPPING FOR THIS ACL
	$acl = $translations->{acl}{$2};
      } else {
	#NUMERIC ACCESS-LIST; FIND THE RANGE AND A RANDOM ACL # IN THAT RANGE
	#FOR EXAMPLE, ACL 50 WOULD TURN INTO RANDOM 0-99, 150 100-199, ETC
	$acl = (int(rand(100)) + (int($2/100)*100));
	$translations->{acl}{$2} = $acl;
      }
      $translatedText = "$1 $acl";
    } elsif( $rawText =~ /(access-list|access\-group|access-class|match ip address) (\S+)/ ) {
      #NAMED ACCESS LIST
      if( defined($translations->{acl}{$2}) ) {
	$acl = $translations->{acl}{$2};
      } else {
	$acl = crypt( $1, join('',(0..9,'A'..'Z','a'..'z')[rand 64, rand 64]));
	$translations->{acl}{$1} = $acl;
      }
      $translatedText = "$1 $acl";
    } elsif( $rawText =~ /((\S+\.)+\S+)/ ) {
      #LOOKS A LITTLE LIKE A HOSTNAME
      $translations->{raw}{$rawText} =
	crypt( $rawText, join( '', (0..9,'A'..'Z', 'a'..'z')[rand 64,rand 64]));
      $translatedText = $translations->{raw}{$rawText};
    } elsif( $rawText =~ /^(\d+):(\d+)$/ ) {
      #COMMUNITY?
      $translations->{raw}{$rawText} = int(rand($1)).":".int(rand($2));
      $translatedText = $translations->{raw}{$rawText};      
    } elsif( $rawText =~ /^(\d+)$/ ) {
      #JUST NUMBERS
      $translations->{raw}{$rawText} = int(rand($1));
      $translatedText = $translations->{raw}{$rawText};
    } elsif( $rawText =~  /md5( \d+)? (\S+)/ ) {
      #MD5 IN HEX
      $translations->{raw}{$rawText} = sprintf( "md5$1 %04X%04X%02X",
						rand 2**16, rand 2**16,
						rand 2**8 );
      $translatedText = $translations->{raw}{$rawText};
    } else {
      #RANDOM TEXT, JUST CRYPT IT
      $translations->{raw}{$rawText} =
	crypt( $rawText, join( '', (0..9,'A'..'Z', 'a'..'z')[rand 64,rand 64]));
      $translatedText = $translations->{raw}{$rawText};
    }
  }
  
  return $translatedText;
}
