# $Id: NCAT.pm,v 3.0.6.3 2004/05/24 17:16:19 nziring Exp $
package NCAT;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

use NCAT::ConfObj;
use NCAT::ConfData;

# hide pseudo-hash warning in 5.8
no warnings 'deprecated';

require Exporter;

#
# $Log: NCAT.pm,v $
# Revision 3.0.6.3  2004/05/24 17:16:19  nziring
# Changed version string for PIX release.
#
# Revision 3.0.6.2  2004/05/11 20:05:32  nziring
# Disabled warnings about deprecated Perl features.
#
# Revision 3.0.6.1  2003/12/30 11:52:20  george
# Brought PIX_DEV branch back into sync with 2.1
#
# Revision 3.1  2003/11/07 12:03:48  george
# 2.1
#
# Revision 3.0.2.1  2003/06/04 14:33:08  george
# Minor changes for Gold Standard Release
#
# Revision 3.0  2003/05/14 11:30:06  george
# Bring everthing up to at least 3.0
#
# Revision 2.15  2003/05/13 15:03:14  george
# Merge 2.0 into mainline
#
# Revision 2.13.2.6  2003/03/02 13:50:06  gmj
# * Version changes, etc. for final 2.0 release
#
# Revision 2.13.2.5  2003/02/09 13:15:10  gmj
# * 2.0 RC2
#
# Revision 2.13.2.4  2003/01/11 22:05:21  gmj
# * Update RAT version number to 1.9
#
# Revision 2.13.2.3  2002/12/30 15:20:59  gmj
# * Removed redundant code
#
# Revision 2.13.2.2  2002/10/04 11:16:28  gmj
# * development snapshot
#
# Revision 2.13.2.1  2002/09/27 17:56:49  gmj
# * Update on branch.
#
# Revision 2.14  2002/09/27 17:22:26  gmj
# 2.0 working versions.  Not a coherent build at this point.
#
# Revision 2.13  2002/08/28 21:45:23  gmj
# * Added RuleInfoNeeded
#
# Revision 2.12  2002/07/26 20:55:28  gmj
# * Added new fields to support autogen of new benchmark format
#
# Revision 2.11  2002/05/22 19:29:13  nziring
# Added allowed global config field names for e-mail notification stuff.
#
# Revision 2.10  2002/04/12 23:11:51  nziring
# Added support for Perl callout processing using RuleCallout: field.
#
# Revision 2.9  2002/03/27 13:17:17  jallison
# commented out check for proper syntax/value in ParseRules to work with $(LOCAL_FOO) style variables
#
# Revision 2.8  2002/03/26 19:03:47  jnssf
# Changed variable declarations so that they remained package specific
# by defined globally using both 'EXPORT_OK' and 'use vars' definition.
# The former makes them available, the latter initializes them to be
# compliant with the 'use strict' command
#
# Revision 2.7  2002/03/21 16:36:35  gmj
# * housecleaning.  Export RuleClassesDefined.
#
# Revision 2.6  2002/03/20 10:43:21  gmj
# * Export global hashes for all rule classes (ConfigGlobal.*,
#   ConfigClass.*, ConfigLocal.*, Rule.*)
# * Added parsing for "ConfigClass.*" fields.
# * Added parsing for "ConfigLocal.*" fields.
# * Made use of lower-case indexes for hashes consistent.
#
# Revision 2.5  2002/03/17 20:07:20  gmj
# * Config parsing moved to common code in NCAT.pm
#
# Revision 2.4  2002/03/07 22:42:18  gmj
# * Backed out bogus change to version
#
# Revision 2.2  2002/03/04 18:56:25  gmj
# Incremented version for 1.1
#
# Revision 2.1  2002/01/24 21:51:15  gmj
# merge back to mainline
#
# Revision 2.0.2.1  2002/01/24 21:35:15  gmj
# Updated version to 1.0
#
# Revision 2.0  2001/12/21 15:23:36  gmj
# Level set version to 2.0 prior to branch for Center for Internet Security.
#
# Revision 1.5  2001/12/21 14:40:23  gmj
# update version to 0.94 for CIS initial release
#
# Revision 1.4  2001/12/20 08:02:31  gmj
# Update $VERSION to 0.93
#
# Revision 1.3  2001/12/14 11:32:11  gmj
# Updated VERSION to 0.92
#
# Revision 1.2  2001/12/11 21:44:12  jnssf
# Changes for allowing 'use NCAT;' to incorporate --version flag,
# misc changes to make code similar to other entries.  Change to NCAT.pm
# so it doesn't use bootstrapping, but instead a function call to ensure
# we no longer need the Auto/Dyna loader routines (which in the end weren't
# used anyway), to allow for the 'use' statements with the .ix or .so files.
#
# Revision 1.1.1.1  2001/11/14 21:40:19  gmj
# Initial CVS checkin.
#
#
# Revision 1.2  2001/11/14 16:40:02  gmj
# Updated for 0.9 rlease
#
#

@ISA = qw(Exporter AutoLoader);
# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.

# @EXPORT = qw(
# );

@NCAT::EXPORT_OK = qw(
     &Version
     %RuleFieldValues
     $Pass $Fail $NoMatch $Match $Error
);

use vars qw(
     %RuleFieldValues
     $Pass $Fail $NoMatch $Match $Error
);

$VERSION = '2.2P';

# Define constants for callouts to return
$Pass = 3;
$Fail = 2;
$Match = 1;
$NoMatch = 0;
$Error = -1;


sub Version { $VERSION };

1;

__END__
