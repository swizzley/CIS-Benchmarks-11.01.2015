package NCAT::ConfObj;
use strict;

# hide pseudo-hash warning in 5.8
no warnings 'deprecated';

=head1 NAME

NCAT::ConfObj - Base object for NCAT Configuration Objects

=head1 SYNOPSIS

  use base 'NCAT::ConfObj';

  # create new object

  $parent = new NCAT::ConfObj(name=>"Adam",		
			      description=>"progenitor",
			      parentname=>"Creator",
			      childrenneeded=>"Cain,Abel",
			      conflictswith=>"Serpent",
			      question=>"eat fruit?",
			      selected=>"yes"
			      );

  # Field names/purpose
  #
  #   name		- unique object name
  #   description	- object description
  #   parentname	- name of parent objects (used to build tree)
  #   childrenneeded	- names of required child objects (comma seperated)
  #   conflictswith	- names of objects that can not be selected if this
  #			  object is selected
  #   question		- A yes/no question that determines if this is
  #			  object is selected.
  #   asked		- Has the question been asked
  #   optional		- Yes/no (default yes) indicating that the object is optional.
  #			  If "no" the question is more of a statement.
  #   selected		- Default answer (yes/no).  Determines if the options was selected.
  #


  # get/set methods are defnied for all fields, e.g.

  $parent->description("Primus Homo");
  my $desc = $parent->description;

  # child/tree access methods are defined

  $parent->add_child ($child);
  $child = $root->lookup("Adam");

  # 

  # debugging/diagnostic

  $root->walk_tree (0);
  $root->dump;

=head1 DESCRIPTION

  This module defines the base datatype for NCAT configuration objects.
  Each object has a unique name, a description and an optional question.
  Each object is marked selected/unselected.  Objects can have any number
  of child objects allowing them to be tree structured.

=head1 AUTHOR

George M. Jones

=head1 SEE ALSO

NCAT::ConfData, NCAT::Conf

=cut

#
# $Log: ConfObj.pm,v $
# Revision 3.0.6.1  2004/05/11 20:06:24  nziring
# Disabled warnings about deprecated Perl features.
#
# Revision 3.0  2003/05/14 11:30:06  george
# Bring everthing up to at least 3.0
#
# Revision 1.2  2003/05/13 15:03:14  george
# Merge 2.0 into mainline
#
# Revision 1.1.2.20  2002/12/27 18:33:20  gmj
# * Added "asked" field
#
# Revision 1.1.2.19  2002/12/25 17:45:46  gmj
# * Updates to pass fullpath argument to walk_tree
#
# Revision 1.1.2.18  2002/12/16 22:44:21  gmj
# * Added dumped method/field
#
# Revision 1.1.2.17  2002/12/12 19:44:56  gmj
# * Added "Optional" field as a yes/no parameter to each object.
#   If "no", then the user is not to be given an option of overriding
#   the default and then "question" is more of a statmenet.
# * Added "parseorder" field to preserve the numerical order in whcih
#   objects were parsed
# * Sort children/walk_tree objects by parse order.
#
# Revision 1.1.2.16  2002/12/10 13:54:05  gmj
# * added is_leaf
#
# Revision 1.1.2.15  2002/12/07 14:25:08  gmj
# * Added remove_child and full_name methods
# * Automatically add parent name to parentname field when new child is added.
# * Added "$parent" as the second argument (first explicit arg) to walk_tree
# * parent passed to walk_tree action routines
#
# Revision 1.1.2.14  2002/11/18 12:24:45  gmj
# * "defaultanswer" became "selected" (yes/no)
#
# Revision 1.1.2.13  2002/11/12 20:42:21  benchoff
# Changed scope of $WALK_PRUNE from my to our.
#
# Revision 1.1.2.12  2002/11/09 15:34:53  gmj
# * Added routine to return list of children
# * Added dump_line routine to allow printing of configs back
#   to a parsable file.
#
# Revision 1.1.2.11  2002/11/07 15:12:15  gmj
# * Added validation checking for required fields
#
# Revision 1.1.2.10  2002/11/06 18:07:08  gmj
# * added children_names method
#
# Revision 1.1.2.9  2002/11/05 21:09:16  gmj
# * added a method to list all object names
#
# Revision 1.1.2.8  2002/11/01 12:57:23  gmj
# * Return $WALK_CONTINUE if depth exceeded (Thanks to Phil Benchoff)
# * Add $WALK_PRUNE as an acceptable return status/action.
#
# Revision 1.1.2.7  2002/10/28 14:41:56  gmj
# * development snapshot
#
# Revision 1.1.2.6  2002/10/11 12:54:13  gmj
# * Development update
#
# Revision 1.1.2.5  2002/10/08 15:21:30  gmj
# * development snapshot
#
# Revision 1.1.2.4  2002/10/04 11:16:28  gmj
# * development snapshot
#
#

use fields qw(

	      name description parentname childrenneeded
	      conflictswith question asked optional selected
	      parseorder dumped

	      _children

	     add_child remove_child
	      lookup dump object_names children_names
	      children dump_line

	      );

#
# Class public data
#

# class should export these return codes for &walk

our $WALK_CONTINUE = 0;
our $WALK_STOP = 1;
our $WALK_FOUND = 2;
our $WALK_PRUNE = 4;

# Class private data

our %ObjectsByName = ();

sub new {
  my NCAT::ConfObj $self = shift;
  unless (ref $self) {
    $self = fields::new($self);
  }

  # set defaults

  $self->{description} = "Default Description";
  $self->{parentname} = undef;
  $self->{childrenneeded} = undef;
  $self->{conflictswith} = undef;
  $self->{question} = undef;
  $self->{asked} = 0;
  $self->{optional} = "yes";
  $self->{selected} = "yes";
  $self->{parseorder} = 9999;
  $self->{dumped} = 0;
  $self->{_children} = [];

  # override defaults

  my ($key,$value);

  
  while (@_ >= 2) {
      $key = shift;
      $value = shift;
      $self->{$key} = $value;
  }

  # Check for required values

  unless (defined($self->{name})) {
    warn("NCAT::ConfObj->new requires a name");
    return undef;
  }

  #
  # Check that parent is previously defined ?
  # Make a child of the parent ?
  #

  # Check for uniqueness

  if (defined ($ObjectsByName{lc $self->{name}})) {
    warn("NCAT::ConfObj->new requires a unique name.  /$self->{name}/ already defined");
    return undef;
  }

  # Index for later quick lookup

  $ObjectsByName{lc $self->{name}} = $self;
  return $self;
}

#
# Get/Set Methods
#

sub name {
  my NCAT::ConfObj $self = shift;
  if (@_) {
    $self->{name} = shift;
    $ObjectsByName{lc $self->{name}} = $self;
  }
  return $self->{name};
}

sub parentname {
  my NCAT::ConfObj $self = shift;
  $self->{parentname} = shift if @_;
  return $self->{parentname};
}

sub childrenneeded {
  my NCAT::ConfObj $self = shift;
  $self->{childrenneeded} = shift if @_;
  return $self->{childrenneeded};
}

sub conflictswith {
  my NCAT::ConfObj $self = shift;
  $self->{conflictswith} = shift if @_;
  return $self->{conflictswith};
}

sub description {
  my NCAT::ConfObj $self = shift;
  $self->{description} = shift if @_;
  return $self->{description};
}

sub question {
  my NCAT::ConfObj $self = shift;
  $self->{question} = shift if @_;
  return $self->{question};
}

sub asked {
  my NCAT::ConfObj $self = shift;
  $self->{asked} = shift if @_;
  return $self->{asked};
}

sub optional {
  my NCAT::ConfObj $self = shift;
  $self->{optional} = shift if @_;
  return $self->{optional};
}

sub selected {
  my NCAT::ConfObj $self = shift;
  $self->{selected} = shift if @_;
  return $self->{selected};
}

sub parseorder {
  my NCAT::ConfObj $self = shift;
  $self->{parseorder} = shift if @_;
  return $self->{parseorder};
}

sub dumped {
  my NCAT::ConfObj $self = shift;
  $self->{dumped} = shift if @_;
  return $self->{dumped};
}

# sort routeine

sub byparseorder {
  $a->{parseorder} <=>   $b->{parseorder};
}



#
# add a child node
#

sub add_child {
  my NCAT::ConfObj $self = shift;
  my NCAT::ConfObj $child = shift;

#  print "add_child: $self->{name} -> $child->{name}\n";

  push @{$self->{_children}},$child;

  # insure that parent name is in parents name list

  if (defined($child->{parentname})) {
      unless ($child->{parentname} =~ /$self->{name}/i) {
	  $child->{parentname} .= ",$self->{name}";
      }
  } else {
      $child->{parentname} = $self->{name};
  }

#  print "add_child:    $child->{parentname} <- $child->{name}\n";
}

sub remove_child {
  my NCAT::ConfObj $self = shift;
  my NCAT::ConfObj $child = shift;
  my @Before = ();
  my @After = ();
  my NCAT::ConfObj $ThisChild;
  my $found = 0;

  for $ThisChild (@{$self->{_children}}) {
      if ($ThisChild eq $child) {
	  $found = 1;
#	  print "remove_child: remove $self->{name} -> $child->{name}\n";
#	  print "remove_child: child->parentname was $child->{parentname}\n";
	  $child->{parentname} =~ s/$self->{name}//i;
	  $child->{parentname} =~ s/^,//;
	  $child->{parentname} =~ s/,,//;
	  $child->{parentname} =~ s/,$//;
#	  print "remove_child: child->parentname is $child->{parentname}\n\n";
      } else {
	  if ($found) {
	      push @After,$ThisChild;
	  } else {
	      push @Before,$ThisChild;
	  }
      }

  }

  @{$self->{_children}} = (@Before,@After);

}



#
# Recursively walk the tree and perform specified action.
#
# The return value of the action routine determines behavior:
#
#	$WALK_CONTINUE		- keep walking
#	$WALK_STOP		- stop walking
#	$WALK_FOUND		- an item has been found
#	$WALK_PRUNE		- prune this element, keep walking.
#	other			- arbitrary value.  Return and stop walking.
#

sub walk_tree {
  my NCAT::ConfObj $self = shift;
  my NCAT::ConfObj $parent = shift;
  my $fullpath = shift;
  my $current_depth = shift;
  my $max_depth = shift;
  my $action = shift;
  my NCAT::ConfObj $child;
  my ($action_status,$walk_status);

#  print "walk_tree: fullpath: $fullpath, self: $self->{name}\n";

  no strict 'refs';

  return $WALK_CONTINUE if ($current_depth > $max_depth);

  $action_status = $action->($self,$parent,"$fullpath:$self->{name}",$current_depth,@_);

  return $action_status if $action_status ne $WALK_CONTINUE;

  my @children = @{$self->{_children}};  # expand here because
					 # walk_tree may change
  					 # list of chilren (e.g.
  					 # by removing/?adding?
  					 # children

  for $child (sort byparseorder @children) {

    $walk_status = $child->walk_tree($self,"$fullpath:$self->{name}",$current_depth+1,$max_depth,$action,@_);

    next if ($walk_status eq $WALK_PRUNE);

    return $walk_status unless ($walk_status eq $WALK_CONTINUE);
  }

  return $WALK_CONTINUE;

}


# lookup an item by name

sub lookup {
  my NCAT::ConfObj $self = shift;
  my $name = shift;

  my ($key,$values);

  return defined($ObjectsByName{lc $name}) ? $ObjectsByName{lc $name} : undef;

}

# determine if a node is a leaf node.

sub is_leaf {
  my NCAT::ConfObj $self = shift;
  my $is_leaf = @{$self->{_children}} == 0;

  return $is_leaf;

}

# Return a list of all object names

sub object_names {
  my NCAT::ConfObj $self = shift;
  my $name = shift;

  my ($key,$values);

  return (keys %ObjectsByName);

}

#
# Return a hash of all all the children of an object
#

sub children_names {
  my NCAT::ConfObj $self = shift;
  my NCAT::ConfObj $child;
  my (%children) = ();

  no strict 'refs';

  for $child (sort byparseorder @{$self->{_children}}) {
    $children{$child->{name}} = $child;
  }

  return %children;
}

#
# Return array of children.
#

sub children {
  my NCAT::ConfObj $self = shift;
  my NCAT::ConfObj $child;
  my (%children) = ();

  no strict 'refs';

  return sort byparseorder @{$self->{_children}};
}


sub dump {
  my NCAT::ConfObj $self = shift;
  my $prefix = shift || "";
  my $fh = shift;

  $self->dump_line ($fh,"${prefix}Name:$self->{name}\n")
    if (defined $self->{name} and not $self->{name} =~ /^\s*$/);
  $self->dump_line ($fh, "${prefix}Description:$self->{description}\n")
    if (defined $self->{description} and not $self->{description} =~ /^\s*$/);
  $self->dump_line ($fh, "${prefix}Parentname:$self->{parentname}\n")
    if (defined $self->{parentname} and not $self->{parentname} =~ /^\s*$/);
  $self->dump_line ($fh, "${prefix}ChildrenNeeded:$self->{childrenneeded}\n")
    if (defined $self->{childrenneeded} and not $self->{childrenneeded} =~ /^\s*$/);
  $self->dump_line ($fh, "${prefix}ConflictsWith:$self->{conflictswith}\n")
    if (defined $self->{conflictswith} and not $self->{conflictswith} =~ /^\s*$/);
  $self->dump_line ($fh, "${prefix}Question:$self->{question}\n")
    if (defined $self->{question} and not $self->{question} =~ /^\s*$/);
#  $self->dump_line ($fh, "${prefix}Asked:$self->{asked}\n")
#    if (defined $self->{asked});
  $self->dump_line ($fh, "${prefix}Optional:$self->{optional}\n")
    if (defined $self->{optional} and not $self->{optional} =~ /^\s*$/);
  $self->dump_line ($fh, "${prefix}Selected:$self->{selected}\n")
    if (defined $self->{selected} and not $self->{selected} =~ /^\s*$/);
  $self->dump_line ($fh, "${prefix}ParseOrder:$self->{parseorder}\n")
    if (defined $self->{parseorder} and not $self->{parseorder} =~ /^\s*$/);

}

#
# print a line to dump, supressing extra CRLFs, adding "\" if need be
#

sub dump_line {
  my ($self) = shift;  # ignored.  This is just a common print-line routine.
  my ($fh,$line) = @_;

  $line =~ s/\n+$//gs; # nuke extra blanklines

  $line =~ s/\n/\\\n/gs; # add continuations where needed
  $line =~ s/\\$//; 	 # Get rid of last one

die "FH not defined" unless (defined $fh);
die "LINE not defined" unless (defined $line);
  print $fh "$line\n";

}


1;

