package NCAT::ConfRule;
use strict;
use base 'NCAT::ConfObj';

# hide pseudo-hash warning in 5.8
no warnings 'deprecated';

=head1 NAME

NCAT::ConfRule - Class that implements NCAT rule element type

=head1 SYNOPSIS

  use 'NCAT::ConfRule';

  # create new object

  $element = new NCAT::ConfRule(name=>"ExternalIF");

  # Unique (non-inherited) field names/purpose
  #
  #   version		- version pattern.  Match in config to see if rule applies.
  #   context		- the rule context (e.g. IOS Line, IOS Interface...)
  #   instance		- instances to wich rule applies (Serial.*)
  #   type		- rule type (required/forbidden)
  #   match		- matching regular expression (instead of callout)
  #   callout		- callout routine (instead of match)
  #   importance	- rule importance.
  #   reason		- reason/justification.
  #   warning		- warnings.
  #   discussion	- references/other info.
  #   fix		- fix script

  # set access methods

  $element->version("version");
  $element->context("context");
  $element->instance("instance");
  $element->type("type");
  $element->match("match");
  $element->importance("importance");
  $element->reason("reason");
  $element->warning("warning");
  $element->discussion("discussion");
  $element->callout("callout");
  $element->fix("fix");

  # get access methods

  $value = $element->reason;
  .
  .
  .

  # debugging/diagnostic

  $element->dump;

=head1 DESCRIPTION

  This module defines the datatype for NCAT rule elements.
  Rule elements are derived from the basic ConfObj datatype
  and have additional fields of: value and default.
  
=head1 AUTHOR

George M. Jones

=head1 SEE ALSO

NCAT::ConfRule, NCAT::Conf

=cut

#
# $Log: ConfRule.pm,v $
# Revision 3.0.6.1  2004/05/11 20:06:24  nziring
# Disabled warnings about deprecated Perl features.
#
# Revision 3.0  2003/05/14 11:30:06  george
# Bring everthing up to at least 3.0
#
# Revision 1.2  2003/05/13 15:03:14  george
# Merge 2.0 into mainline
#
# Revision 1.1.2.5  2002/11/17 16:54:49  gmj
# * removed level attribute
#
# Revision 1.1.2.4  2002/11/09 15:33:17  gmj
# * Updated dump routine to print out either heirarcy or parsable config
#
# Revision 1.1.2.3  2002/10/08 15:21:30  gmj
# * development snapshot
#
# Revision 1.1.2.2  2002/10/04 11:16:28  gmj
# * development snapshot
#
#

use fields qw(
	version
	context
	instance
	type
	match
	importance
	reason
	warning
	discussion
	callout
	fix
);


sub new {
  my $class = shift;
  my $self = fields::new($class);


  # call base class constructor
  
  $self->SUPER::new(@_);

  # set defaults

  $self->version("");
  $self->context("");
  $self->instance("");
  $self->type("Required");
  $self->match("");
  $self->importance(5);
  $self->reason("");
  $self->warning("");
  $self->discussion("");
  $self->callout("");
  $self->fix("");


  
  #  # Check for required values
  #
  #  unless (defined($self->{name})) {
  #    warn("ConfObj->new requires a name");
  #    return undef;
  #  }
  #
  
  return $self;
}

sub version {
  my NCAT::ConfRule $self = shift;
  $self->{version} = shift if @_;
  return $self->{version};
}

sub context {
  my NCAT::ConfRule $self = shift;
  $self->{context} = shift if @_;
  return $self->{context};
}

sub instance {
  my NCAT::ConfRule $self = shift;
  $self->{instance} = shift if @_;
  return $self->{instance};
}

sub type {
  my NCAT::ConfRule $self = shift;
  $self->{type} = shift if @_;
  return $self->{type};
}

sub match {
  my NCAT::ConfRule $self = shift;
  $self->{match} = shift if @_;
  return $self->{match};
}

sub importance {
  my NCAT::ConfRule $self = shift;
  $self->{importance} = shift if @_;
  return $self->{importance};
}

sub reason {
  my NCAT::ConfRule $self = shift;
  $self->{reason} = shift if @_;
  return $self->{reason};
}

sub warning {
  my NCAT::ConfRule $self = shift;
  $self->{warning} = shift if @_;
  return $self->{warning};
}

sub discussion {
  my NCAT::ConfRule $self = shift;
  $self->{discussion} = shift if @_;
  return $self->{discussion};
}

sub callout {
  my NCAT::ConfRule $self = shift;
  $self->{callout} = shift if @_;
  return $self->{callout};
}

sub fix {
  my NCAT::ConfRule $self = shift;
  $self->{fix} = shift if @_;
  return $self->{fix};
}

sub dump {
  my NCAT::ConfRule $self = shift;
  my $prefix = shift;
  my $fh = shift;
  my $field;
  no strict 'refs';

  $self->SUPER::dump($prefix,$fh);

  for $field ("Version","Context","Instance",
	      "Type","Match","Importance","Reason",
              "Warning","Discussion","Callout","Fix") {
    $self->dump_line ($fh, "$prefix$field:$self->{lc $field}\n")
      if (defined $self->{lc $field} and not ($self->{lc $field} =~ /^\s*$/));
  }
  print $fh "\n";
}

1;
