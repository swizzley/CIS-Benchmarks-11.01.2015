# $Id: IOSTest.pm,v 3.0 2003/05/14 11:30:07 george Exp $

package NCAT::IOSTest;

use NCAT;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

require Exporter;

# CVS commit log
#
# $Log: IOSTest.pm,v $
# Revision 3.0  2003/05/14 11:30:07  george
# Bring everthing up to at least 3.0
#
# Revision 1.4  2002/08/28 19:11:18  nziring
# Added enable secret re-use callout (MD5 and BSD crypt)
#
# Revision 1.3  2002/06/05 15:32:59  nziring
# Fixed bug in password quality checking rule callout.
#
# Revision 1.2  2002/05/31 15:41:58  nziring
# Took out some debug prints from rule callout functions.
#
# Revision 1.1  2002/04/26 13:43:15  nziring
# Library of functions for IOS configuration testing,
# intended for use as Rule Callouts.
#
#


@ISA = qw(Exporter AutoLoader);
# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.
# @EXPORT = qw(	
# );

@NCAT::IOSTest::EXPORT_OK = qw(
	&CheckBufferingSizeMin
	&CheckIOSPasswordQuality
	&MatchAtLeast
	&CheckIOSSecretReuse
);

use vars qw(
	&CheckBufferingSizeMin
	&CheckIOSPasswordQuality
	&MatchAtLeast
	&CheckIOSSecretReuse
);


sub Version { $VERSION };

# Preloaded methods go here.

#
# CheckIOSSecretReuse - this function as an NCAT Callout Function
#
# Check for re-use of other passwords as IOS enable secret
# (encryption type 5) values.  The basic approach here is
# to search the entire configuration for plain-text and
# type 7 encrypted passwords, and they use them as a dictionary
# to check the enable secret type 5 password.  If 
# the enable secret is the same as any of the other passwords,
# then we return $NCAT::Fail, otherwise we return $NCAT::Pass.
# 
# In a RAT rule, this callout can accept 0 or 1 optional parameters.
# If given, the first optional parameter should be a small number,
# the maximum number of seconds (wall-clock time) of processing we
# should devote to testing passwords.  If the parameter is not
# given, then it defaults to 20 seconds.  The minimum permitted
# value is 1 second.  Suggested value is 10 seconds, so the
# rule callout field would look like this:
#     rulecallout:IOSTest::CheckIOSSecretReuse,10
#
# If the MatchText does not seem to have a type 5 encrypted password
# in it, then we punt and return $NCAT::NoMatch.  If the maximum time
# is exceeded we punt and return $NCAT::Pass.
#
sub CheckIOSSecretReuse
{
    my ($Text, $MatchText, $LineNum, $Rule, $Instance, $RuleAttrRef, $MaxTime) = @_;
    my $KnownEPW;
    my $pw;
    my $line;
    my $OtherEPW;
    my $StartTime;
    my $NowTime;
    my $pwnum;

    if (!defined($MaxTime)) {
	$MaxTime = 20;
    }
    $MaxTime = abs($MaxTime);
    if ($MaxTime < 1) {
	$MaxTime = 1;
    }
    if ($MatchText =~ m/5\s+(\$1\$[^ ]+)/) {
	$KnownEPW = $1;
    } else {
	return $NCAT::NoMatch;
    }

    # now retrieve all the OTHER passwords from the configuration (no dups)
    my %OtherPW;
    foreach $line (split /\n/,$Text) {
	chomp $line;
	$pw = extractCiscoPassword($line);
	if ($pw) {
	    $OtherPW{$pw} = $pw;
	}
    }

    # Procedure above grabs "-encryption" from "service password-encryption"
    # command so remove it from the set of candidate passwords.
    delete $OtherPW{'-encryption'};

    # get the computation start time
    $StartTime = time();

    # Now attempt a match on each unique password,
    # this is rather computationally expensive so don't spend more
    # than $MaxTime seconds.
    $pwnum = 0;
    PW: foreach $pw (keys %OtherPW) {
	$pwnum += 1;
	if (testCandidatePassword($KnownEPW, $pw)) {
	    # If we get here, one of the lightly-covered passwords is the SAME
	    # as the enable secret!  We fail!
#	    print STDERR "Debug CheckIOSSecretReuse: found match to password $pw !\n";
	    return $NCAT::Fail;
	}
	$NowTime = time();
	if (($NowTime - $StartTime) >= $MaxTime) {
	    print STDERR "CheckIOSSecretReuse: Maximum time " . $MaxTime . "s exceeded\n\tin checking password no. $pwnum -- Bailing out.\n";
	    last PW;
	}
    }

    # if we get here, none matched, so we pass!
    return $NCAT::Pass;
}

#
# CheckBufferingSizeMin - this function is an NCAT Callout Function
#
# Check the buffering size.  The MatchText should
# be an IOS logging configuration setting of the
# basic format "logging buffered \d+".  We want to
# check that the amount is greater than or equal to
# a specified minimum.  The minimum must be specified
# as the first optional argument to the function, in
# the rule callout field.  For example, the line in
# the ncat.conf file might look like this:
#      RuleCallout: NCAT::IOSTest::CheckBufferingSizeMin,30000
# 
# There are three possible return values from this
# function:
#   1. $NCAT::NoMatch -
#      if the RuleMatch text does not match the format
#      of a logging configuration statement.
#
#   2. $NCAT::Pass
#      if the logging buffer size is >= the minimum
#      size specified as the first argument.
#
#   3. $NCAT::Fail
#      otherwise
#
# This function should always be called from a scalar
# context.  For more information, consult the comments
# of the function ProcessCallout in ncat.PL.
#
sub CheckBufferingSizeMin
{
    my ($Text, $MatchText, $LineNum, $Rule, $Instance, $RuleAttrRef, $MinSize) = @_;
    my $BufAmt;
    my $ret = $NCAT::NoMatch;

    if($MatchText =~ m/logging *buffered *(\d+)/) {
	$BufAmt = $1;
	$ret = (($BufAmt >= $MinSize) ? $NCAT::Pass : $NCAT::Fail );
    }
    return $ret;
}

# This Perl code breaks back Cisco passwords encoded with
# IOS type 7 "encryption".  The algorithm used here is
# based partly on the ciscocrack program by a shadowy figure 
# called only 'Dr. Delete'.  According to Thomas Akin, the
# cipher used by type 7 is a Vigenere cipher.
#
# Change History
#
#  Version 0.1		Neal Ziring, NSA	3/6/02
#  Version 0.2		Neal Ziring, NSA	3/20/02
#

#
# Given a Cisco type 7 password string, return the plaintext
# password if possible.  Return the empty string if the
# supplied argument cannot be a valid Cisco 
# Input must be scalar and be a single string of the form
# specified for Cisco passwords: 0 or 1 followed by at least
# three characters.  In a list context, this function returns
# a two-element list, the first element the decoded password
# and the second element an error message about why the 
# password could not be decoded.
#
sub decodeCiscoType7Password {
    my $enc = shift;
    my $hexcodes;
    my $offset;
    my $magic = "dsfd;kfoA,.iyewrkldJKDHSUB";
    my $pos = 0;
    my $val;
    my $len;
    my $magiclen;
    my @hx;
    my $result;
    
    # return immediately if some sanity conditions arent met
    if (!($enc =~ m/^[01][0-9]([0-9a-fA-F][0-9a-fA-F])+$/)) {
	return wantarray ? ("", "Bad format for encoded password"): "";
    }
    # Cisco passwords are supposed to be 4-11 chars in length,
    # otherwise the 'magic' block runs out, so check length here.
    if (length($enc) > 104) {
	return wantarray ? ("", "Encoded password is too long"): "";
    }

    # get the offset from the first two bytes of the string (decimal not octal)
    if ($enc =~ m/^0/) {
	$offset = substr($enc, 1,1);
    }
    else {
	$offset = substr($enc, 0,2);
    }

    # extract the encoded part of the string
    $hexcodes = substr($enc, 2);

    # use the offset to extract the part of the magic block to use
    $magiclen = length($magic);
    $magic = substr($magic, $offset);

    # for each pair of hex digits in hexcodes, xor with
    # the appropriate byte of magic to get password char
    # (there must be a way to do this with unpack!)
    $pos = 0;
    @hx = ();
    while ($pos < length($hexcodes)) {
	$val = hex(substr($hexcodes, $pos, 2));
	$val = $val ^ ord(substr($magic, ($pos/2) % $magiclen, 1));
	push @hx, $val;
	$pos = $pos + 2;
    }
    $result = pack("c*", @hx);
    return wantarray ? ($result, "") : $result;
}

    
#
# Given a line of a Cisco configuration file that might
# contain a password, return the password type as an
# integer.  Possible return values are:
#     -1 = no password appears to be present, 
#      0 = plaintext password
#      5 = MD5 hash of password, 
#      7 = cisco reversible encoded password.  
# 
# This function expects one string argument and should
# always be called in scalar context.
#
sub getCiscoPasswordType {
    my $line = shift;
    return 7 if ($line =~ m/^.*[Pp]assword *7 *([0-9a-fA-F]+) *$/);
    return 5 if ($line =~ m/^.*(([Pp]assword)|([Ss]ecret)) *5 *([^ ]+)$/);
    return 0 if ($line =~ m/^.*[Pp]assword *[^ ]+.+ *$/);
    return -1;
}

#
# Given a line of a Cisco configuration file containing
# a password, attempt to grab the encoded password out 
# of it and return it, if possible.  This function accepts
# exactly one string argument.  This function handles
# Cisco type 0 and type 7.  If this function cannot find 
# or cannot decode the password, then it return an empty
# string.  If called in list context, it returns a two-element
# list: the first element is the decoded password, the
# second is an error message about why the password couldnt
# be decoded.
#
# This routine recognizes two formats:
#          .* password 7 [hexdigits] - type 7 decoding okay
#          .* password 5 [base64]   - cannot decode this
#          .* password [word]  - plaintext okay
#
sub extractCiscoPassword {
    my $line = shift;
    
    if ($line =~ s/^.*[Pp]assword *7 *([0-9a-fA-F]+) *$/$1/) {
	return decodeCiscoType7Password($line);
    } elsif ($line =~ s/^.*(([Pp]assword)|([Ss]ecret)) *5 *([^ ]+) *$/$4/) {
	return wantarray ? ('', "Cannot decode type 5 passwords") : '';
    } elsif ($line =~ s/^.*[Pp]assword *0? *([^ ].*)$/$1/) {
	return wantarray ? ($line, '') : $line;
    } else {
	return wantarray ? ('', 'No password found in line') : '';
    }
}



#
# Given a password in plaintext, compute a quality metric
# on it.  The metric itself is the one used by Mozilla 0.9.8,
# it computes a quality metric between 0 and 100 as follows:
#    L = length of password, 0-5 (more than 5 scores 5)
#    N = number of digit characters, 0-3 (more than 3 scores 3)
#    W = number of non-alphanumerics, 0-3 (more than 3 scores 3)
#    U = number of uppercase letters, 0-3 (more than 3 scores 3)
#
#    score = ((L*10)-20)+(N*10)+(W*15)+(U*10)
#    (any score < 0 is adjusted to 0)
#
# This function should be called with a single string argument,
# and only in scalar context.
#
sub computePasswordQuality {
    my $pass = shift;
    my $L;
    my $N;
    my $W;
    my $U;
    my $score;
    my $tmp;
    
    # length, max score 5
    $L = length($pass);
    $L = 5 if ($L > 5);

    # count of numeric chars, max score 3
    $tmp = $pass;
    $tmp =~ y/[0-9]//d;
    $N = length($pass) - length($tmp);
    $N = 3 if ($N > 3);

    # count of non-word chars, max score 3
    $tmp = $pass;
    $tmp =~ y/[A-Za-z0-9]//d;
    $W = length($tmp);
    $W = 3 if ($W > 3);
    
    # count of uppercase letters, max score 3
    $tmp = $pass;
    $tmp =~ y/[A-Z]//d;
    $U = length($pass) - length($tmp);
    $U = 3 if ($U > 3);
    
    # compute final score, adjust to range 0-100
    $score = (($L * 10) - 20) + ($N * 10) + ($W * 15) + ($U * 10);
    $score = 0 if ($score < 0);
    $score = 100 if ($score > 100);
    
    # return final score as a scalar
    return $score;
}



#
# CheckIOSPasswordQuality - this function is an NCAT Callout Function
#
# Check the quality of a plaintext or type 7 password 
# in a Cisco IOS configuration.  The configuration statement
# with the password in it is expected as the MatchText argument.
#
# The quality of a password
# is expressed as a number 0-100, where 0 is no password
# and 100 is an excellent password with a good mix of
# stuff (see above).  Used as a RuleCallout function,
# this function expects one additional argument, a minimum
# quality.  It is done this way to allow the value that
# distinguishes pass/fail to be expressed in the rules file
# where it belongs.
#
# If you were writing a Rat rule that used this callout it
# might look like this
#
#      RuleMatch: password .+$ 
#      RuleCallout: NCAT::IOSTest::CheckIOSPasswordQuality,60,password.+
#
# Note that a quality lower bound and a password statement matching
# regular expression must be given.  This callout function checks
# ALL matching lines in the instance text, and returns Fail if any
# of them fail, and Pass if all of them pass.
# 
# There are three possible return values from this
# function:
#   1. $NCAT::NoMatch -
#      no password could be found in the match text      
#
#   2. $NCAT::Pass
#      the quality of the password(s) exceeded the minimum
#      value given as the first argument.
#
#   3. $NCAT::Fail
#      otherwise
#
# This function should always be called from a scalar
# context.  For more information, consult the comments
# of the function ProcessCallout in ncat.PL.
#
#
sub CheckIOSPasswordQuality
{
    my ($Text, $MatchText, $LineNum, $Rule, $Instance, $RuleFieldsRef, $MinQuality,$Expr) = @_;
    my ($Passwd, $Qual);
    my $ret = $NCAT::NoMatch;
    my @lines;
    my $line;
#    print STDERR "Arrived in CheckIOSPasswordQuality, Text='$Text' MatchText='$MatchText' LineNum=$LineNum\n";
    @lines = split(/\n/, $Text);
#    print STDERR "Number of lines is " . ($#lines - 1) . "\n";
    foreach $line (@lines) {
	if ($line =~ m/$Expr/) {
#	    print STDERR "Line=" . $line . "\n";
	    $Passwd = extractCiscoPassword($line);
#	    print STDERR "Got password '$Passwd'\n";
	    if ($Passwd) {
		$Qual = computePasswordQuality($Passwd);
#		print STDERR " quality=$Qual \n";
		$ret = (($Qual > $MinQuality)? $NCAT::Pass : $NCAT::Fail );
#		print STDERR "Check IOS Passwd Quality Returning $ret \n";
		if ($ret == $NCAT::Fail) {
		    return $ret;
		}
	    }
	}
    }
    return $ret;
}


#
# MatchAtLeast - this function is an NCAT Callout Function
#
# Given M regular expressions, and a count 0<N<=M, return
# $NCAT::Match if at least N expressions match the
# text, and $NCAT::Fail otherwise.
# 
# The text is the complete text (without spaces!  argh!)
# of the current ncat context.
# This callout function is meant to be used when you have
# a rule that requires two or more patterns to be present
# in the text, but their order does not matter.
#
# If you were writing a Rat rule that used this callout it
# might look like this
#
#   RuleCallout: IOSTest::MatchAtLeast,2,pat1,pat2,pat3,pat4
# 
# This function should always be called from a scalar
# context.  For more information, consult the comments
# of the function ProcessCallout in ncat.PL.
#
sub MatchAtLeast
{
    my ($Text, $MatchText, $LineNum, $Rule, $Instance, $RuleFieldsRef, $NeedAtLeast, @Patterns) = @_;
    my ($Found, $ndx, $pat);
    $Found = 0;
    
    $ndx = 0;
    while($ndx <= $#Patterns) {
	$pat = $Patterns[$ndx];
#	print STDERR "Trying pattern '$pat'..\n";
	if ($Text =~ m/$pat/mi) {
	    $Found += 1;
#	    print STDERR "     found it!\n";
	}
	$ndx++;
    }
    if ($Found >= $NeedAtLeast) {
	return $NCAT::Match;
    } else {
	return $NCAT::NoMatch;
    }
}


#
# Simplified implementation of MD5 in Perl
# adapted from Digest::MD5::Perl by C. Lackas
#
# Original Perl code Copyright 2000 Christian Lackas,Imperia Software Solutions
# Original C code Copyright 1991-1992 RSA Data Security, Inc.
#
# Neal Ziring, August 2002
# 

use integer;

sub A() { 0x67_45_23_01 }
sub B() { 0xef_cd_ab_89 }
sub C() { 0x98_ba_dc_fe }
sub D() { 0x10_32_54_76 }

sub MAX() { 0xFFFFFFFF }

sub padding($) {
    my $l = length (my $msg = shift() . chr(128));    
    $msg .= "\0" x (($l%64<=56?56:120)-$l%64);
    $l = ($l-1)*8;
    $msg .= pack 'VV', $l & MAX , ($l >> 16 >> 16);
}


sub rotate_left($$) {
	($_[0] << $_[1]) | (( $_[0] >> (32 - $_[1])  )  & ((1 << $_[1]) - 1));
}


sub round {
    my ($a,$b,$c,$d) = @_[0 .. 3];
    my $r;

    # rounds generated by C. Lackas function gen_code().
    $r = ($d^($b&($c^$d)))+$a+$_[4]+0xd76aa478 & 4294967295;
    $a = (($r << 7) | (($r >> (32 - 7))  & ((1 << 7) - 1))) + $b & 4294967295;
    $r = ($c^($a&($b^$c)))+$d+$_[5]+0xe8c7b756 & 4294967295;
    $d = (($r << 12) | (($r >> (32 - 12))  & ((1 << 12) - 1))) + $a & 4294967295;
    $r = ($b^($d&($a^$b)))+$c+$_[6]+0x242070db & 4294967295;
    $c = (($r << 17) | (($r >> (32 - 17))  & ((1 << 17) - 1))) + $d & 4294967295;
    $r = ($a^($c&($d^$a)))+$b+$_[7]+0xc1bdceee & 4294967295;
    $b = (($r << 22) | (($r >> (32 - 22))  & ((1 << 22) - 1))) + $c & 4294967295;
    $r = ($d^($b&($c^$d)))+$a+$_[8]+0xf57c0faf & 4294967295;
    $a = (($r << 7) | (($r >> (32 - 7))  & ((1 << 7) - 1))) + $b & 4294967295;
    $r = ($c^($a&($b^$c)))+$d+$_[9]+0x4787c62a & 4294967295;
    $d = (($r << 12) | (($r >> (32 - 12))  & ((1 << 12) - 1))) + $a & 4294967295;
    $r = ($b^($d&($a^$b)))+$c+$_[10]+0xa8304613 & 4294967295;
    $c = (($r << 17) | (($r >> (32 - 17))  & ((1 << 17) - 1))) + $d & 4294967295;
    $r = ($a^($c&($d^$a)))+$b+$_[11]+0xfd469501 & 4294967295;
    $b = (($r << 22) | (($r >> (32 - 22))  & ((1 << 22) - 1))) + $c & 4294967295;
    $r = ($d^($b&($c^$d)))+$a+$_[12]+0x698098d8 & 4294967295;
    $a = (($r << 7) | (($r >> (32 - 7))  & ((1 << 7) - 1))) + $b & 4294967295;
    $r = ($c^($a&($b^$c)))+$d+$_[13]+0x8b44f7af & 4294967295;
    $d = (($r << 12) | (($r >> (32 - 12))  & ((1 << 12) - 1))) + $a & 4294967295;
    $r = ($b^($d&($a^$b)))+$c+$_[14]+0xffff5bb1 & 4294967295;
    $c = (($r << 17) | (($r >> (32 - 17))  & ((1 << 17) - 1))) + $d & 4294967295;
    $r = ($a^($c&($d^$a)))+$b+$_[15]+0x895cd7be & 4294967295;
    $b = (($r << 22) | (($r >> (32 - 22))  & ((1 << 22) - 1))) + $c & 4294967295;
    $r = ($d^($b&($c^$d)))+$a+$_[16]+0x6b901122 & 4294967295;
    $a = (($r << 7) | (($r >> (32 - 7))  & ((1 << 7) - 1))) + $b & 4294967295;
    $r = ($c^($a&($b^$c)))+$d+$_[17]+0xfd987193 & 4294967295;
    $d = (($r << 12) | (($r >> (32 - 12))  & ((1 << 12) - 1))) + $a & 4294967295;
    $r = ($b^($d&($a^$b)))+$c+$_[18]+0xa679438e & 4294967295;
    $c = (($r << 17) | (($r >> (32 - 17))  & ((1 << 17) - 1))) + $d & 4294967295;
    $r = ($a^($c&($d^$a)))+$b+$_[19]+0x49b40821 & 4294967295;
    $b = (($r << 22) | (($r >> (32 - 22))  & ((1 << 22) - 1))) + $c & 4294967295;
    $r = ($c^($d&($b^$c)))+$a+$_[5]+0xf61e2562 & 4294967295;
    $a = (($r << 5) | (($r >> (32 - 5))  & ((1 << 5) - 1))) + $b & 4294967295;
    $r = ($b^($c&($a^$b)))+$d+$_[10]+0xc040b340 & 4294967295;
    $d = (($r << 9) | (($r >> (32 - 9))  & ((1 << 9) - 1))) + $a & 4294967295;
    $r = ($a^($b&($d^$a)))+$c+$_[15]+0x265e5a51 & 4294967295;
    $c = (($r << 14) | (($r >> (32 - 14))  & ((1 << 14) - 1))) + $d & 4294967295;
    $r = ($d^($a&($c^$d)))+$b+$_[4]+0xe9b6c7aa & 4294967295;
    $b = (($r << 20) | (($r >> (32 - 20))  & ((1 << 20) - 1))) + $c & 4294967295;
    $r = ($c^($d&($b^$c)))+$a+$_[9]+0xd62f105d & 4294967295;
    $a = (($r << 5) | (($r >> (32 - 5))  & ((1 << 5) - 1))) + $b & 4294967295;
    $r = ($b^($c&($a^$b)))+$d+$_[14]+0x2441453 & 4294967295;
    $d = (($r << 9) | (($r >> (32 - 9))  & ((1 << 9) - 1))) + $a & 4294967295;
    $r = ($a^($b&($d^$a)))+$c+$_[19]+0xd8a1e681 & 4294967295;
    $c = (($r << 14) | (($r >> (32 - 14))  & ((1 << 14) - 1))) + $d & 4294967295;
    $r = ($d^($a&($c^$d)))+$b+$_[8]+0xe7d3fbc8 & 4294967295;
    $b = (($r << 20) | (($r >> (32 - 20))  & ((1 << 20) - 1))) + $c & 4294967295;
    $r = ($c^($d&($b^$c)))+$a+$_[13]+0x21e1cde6 & 4294967295;
    $a = (($r << 5) | (($r >> (32 - 5))  & ((1 << 5) - 1))) + $b & 4294967295;
    $r = ($b^($c&($a^$b)))+$d+$_[18]+0xc33707d6 & 4294967295;
    $d = (($r << 9) | (($r >> (32 - 9))  & ((1 << 9) - 1))) + $a & 4294967295;
    $r = ($a^($b&($d^$a)))+$c+$_[7]+0xf4d50d87 & 4294967295;
    $c = (($r << 14) | (($r >> (32 - 14))  & ((1 << 14) - 1))) + $d & 4294967295;
    $r = ($d^($a&($c^$d)))+$b+$_[12]+0x455a14ed & 4294967295;
    $b = (($r << 20) | (($r >> (32 - 20))  & ((1 << 20) - 1))) + $c & 4294967295;
    $r = ($c^($d&($b^$c)))+$a+$_[17]+0xa9e3e905 & 4294967295;
    $a = (($r << 5) | (($r >> (32 - 5))  & ((1 << 5) - 1))) + $b & 4294967295;
    $r = ($b^($c&($a^$b)))+$d+$_[6]+0xfcefa3f8 & 4294967295;
    $d = (($r << 9) | (($r >> (32 - 9))  & ((1 << 9) - 1))) + $a & 4294967295;
    $r = ($a^($b&($d^$a)))+$c+$_[11]+0x676f02d9 & 4294967295;
    $c = (($r << 14) | (($r >> (32 - 14))  & ((1 << 14) - 1))) + $d & 4294967295;
    $r = ($d^($a&($c^$d)))+$b+$_[16]+0x8d2a4c8a & 4294967295;
    $b = (($r << 20) | (($r >> (32 - 20))  & ((1 << 20) - 1))) + $c & 4294967295;
    $r = ($b^$c^$d)+$a+$_[9]+0xfffa3942 & 4294967295;
    $a = (($r << 4) | (($r >> (32 - 4))  & ((1 << 4) - 1))) + $b & 4294967295;
    $r = ($a^$b^$c)+$d+$_[12]+0x8771f681 & 4294967295;
    $d = (($r << 11) | (($r >> (32 - 11))  & ((1 << 11) - 1))) + $a & 4294967295;
    $r = ($d^$a^$b)+$c+$_[15]+0x6d9d6122 & 4294967295;
    $c = (($r << 16) | (($r >> (32 - 16))  & ((1 << 16) - 1))) + $d & 4294967295;
    $r = ($c^$d^$a)+$b+$_[18]+0xfde5380c & 4294967295;
    $b = (($r << 23) | (($r >> (32 - 23))  & ((1 << 23) - 1))) + $c & 4294967295;
    $r = ($b^$c^$d)+$a+$_[5]+0xa4beea44 & 4294967295;
    $a = (($r << 4) | (($r >> (32 - 4))  & ((1 << 4) - 1))) + $b & 4294967295;
    $r = ($a^$b^$c)+$d+$_[8]+0x4bdecfa9 & 4294967295;
    $d = (($r << 11) | (($r >> (32 - 11))  & ((1 << 11) - 1))) + $a & 4294967295;
    $r = ($d^$a^$b)+$c+$_[11]+0xf6bb4b60 & 4294967295;
    $c = (($r << 16) | (($r >> (32 - 16))  & ((1 << 16) - 1))) + $d & 4294967295;
    $r = ($c^$d^$a)+$b+$_[14]+0xbebfbc70 & 4294967295;
    $b = (($r << 23) | (($r >> (32 - 23))  & ((1 << 23) - 1))) + $c & 4294967295;
    $r = ($b^$c^$d)+$a+$_[17]+0x289b7ec6 & 4294967295;
    $a = (($r << 4) | (($r >> (32 - 4))  & ((1 << 4) - 1))) + $b & 4294967295;
    $r = ($a^$b^$c)+$d+$_[4]+0xeaa127fa & 4294967295;
    $d = (($r << 11) | (($r >> (32 - 11))  & ((1 << 11) - 1))) + $a & 4294967295;
    $r = ($d^$a^$b)+$c+$_[7]+0xd4ef3085 & 4294967295;
    $c = (($r << 16) | (($r >> (32 - 16))  & ((1 << 16) - 1))) + $d & 4294967295;
    $r = ($c^$d^$a)+$b+$_[10]+0x4881d05 & 4294967295;
    $b = (($r << 23) | (($r >> (32 - 23))  & ((1 << 23) - 1))) + $c & 4294967295;
    $r = ($b^$c^$d)+$a+$_[13]+0xd9d4d039 & 4294967295;
    $a = (($r << 4) | (($r >> (32 - 4))  & ((1 << 4) - 1))) + $b & 4294967295;
    $r = ($a^$b^$c)+$d+$_[16]+0xe6db99e5 & 4294967295;
    $d = (($r << 11) | (($r >> (32 - 11))  & ((1 << 11) - 1))) + $a & 4294967295;
    $r = ($d^$a^$b)+$c+$_[19]+0x1fa27cf8 & 4294967295;
    $c = (($r << 16) | (($r >> (32 - 16))  & ((1 << 16) - 1))) + $d & 4294967295;
    $r = ($c^$d^$a)+$b+$_[6]+0xc4ac5665 & 4294967295;
    $b = (($r << 23) | (($r >> (32 - 23))  & ((1 << 23) - 1))) + $c & 4294967295;
    $r = ($c^($b|(~$d)))+$a+$_[4]+0xf4292244 & 4294967295;
    $a = (($r << 6) | (($r >> (32 - 6))  & ((1 << 6) - 1))) + $b & 4294967295;
    $r = ($b^($a|(~$c)))+$d+$_[11]+0x432aff97 & 4294967295;
    $d = (($r << 10) | (($r >> (32 - 10))  & ((1 << 10) - 1))) + $a & 4294967295;
    $r = ($a^($d|(~$b)))+$c+$_[18]+0xab9423a7 & 4294967295;
    $c = (($r << 15) | (($r >> (32 - 15))  & ((1 << 15) - 1))) + $d & 4294967295;
    $r = ($d^($c|(~$a)))+$b+$_[9]+0xfc93a039 & 4294967295;
    $b = (($r << 21) | (($r >> (32 - 21))  & ((1 << 21) - 1))) + $c & 4294967295;
    $r = ($c^($b|(~$d)))+$a+$_[16]+0x655b59c3 & 4294967295;
    $a = (($r << 6) | (($r >> (32 - 6))  & ((1 << 6) - 1))) + $b & 4294967295;
    $r = ($b^($a|(~$c)))+$d+$_[7]+0x8f0ccc92 & 4294967295;
    $d = (($r << 10) | (($r >> (32 - 10))  & ((1 << 10) - 1))) + $a & 4294967295;
    $r = ($a^($d|(~$b)))+$c+$_[14]+0xffeff47d & 4294967295;
    $c = (($r << 15) | (($r >> (32 - 15))  & ((1 << 15) - 1))) + $d & 4294967295;
    $r = ($d^($c|(~$a)))+$b+$_[5]+0x85845dd1 & 4294967295;
    $b = (($r << 21) | (($r >> (32 - 21))  & ((1 << 21) - 1))) + $c & 4294967295;
    $r = ($c^($b|(~$d)))+$a+$_[12]+0x6fa87e4f & 4294967295;
    $a = (($r << 6) | (($r >> (32 - 6))  & ((1 << 6) - 1))) + $b & 4294967295;
    $r = ($b^($a|(~$c)))+$d+$_[19]+0xfe2ce6e0 & 4294967295;
    $d = (($r << 10) | (($r >> (32 - 10))  & ((1 << 10) - 1))) + $a & 4294967295;
    $r = ($a^($d|(~$b)))+$c+$_[10]+0xa3014314 & 4294967295;
    $c = (($r << 15) | (($r >> (32 - 15))  & ((1 << 15) - 1))) + $d & 4294967295;
    $r = ($d^($c|(~$a)))+$b+$_[17]+0x4e0811a1 & 4294967295;
    $b = (($r << 21) | (($r >> (32 - 21))  & ((1 << 21) - 1))) + $c & 4294967295;
    $r = ($c^($b|(~$d)))+$a+$_[8]+0xf7537e82 & 4294967295;
    $a = (($r << 6) | (($r >> (32 - 6))  & ((1 << 6) - 1))) + $b & 4294967295;
    $r = ($b^($a|(~$c)))+$d+$_[15]+0xbd3af235 & 4294967295;
    $d = (($r << 10) | (($r >> (32 - 10))  & ((1 << 10) - 1))) + $a & 4294967295;
    $r = ($a^($d|(~$b)))+$c+$_[6]+0x2ad7d2bb & 4294967295;
    $c = (($r << 15) | (($r >> (32 - 15))  & ((1 << 15) - 1))) + $d & 4294967295;
    $r = ($d^($c|(~$a)))+$b+$_[13]+0xeb86d391 & 4294967295;
    $b = (($r << 21) | (($r >> (32 - 21))  & ((1 << 21) - 1))) + $c & 4294967295;

    $_[0]+$a & 4294967295, $_[1]+$b  & 4294967295, $_[2]+$c & 4294967295, $_[3]+$d & 4294967295;
}

#
# Compute MD5 of a chunk of data and return the hash as a
# 16-character binary string scalar.
#
sub md5(@) {
	my $message = padding(join('',@_));
	my ($a,$b,$c,$d) = (A,B,C,D);
	my $i;
	for $i (0 .. (length $message)/64 - 1) {
		my @X = unpack 'V16', substr $message,$i*64,64;	
		($a,$b,$c,$d) = round($a,$b,$c,$d,@X);
	}
	pack 'V4',$a,$b,$c,$d;
}

sub md5_hex(@) {  
  unpack 'H*', &md5;
}


#
# Perl implementation of FreeBSD MD5 password format, adapted from
# BSD crypt implementation crypt.c by P-H Kamp.
#
# Neal Ziring, August 2002.
#

my $itoa64 = "./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

sub to64($$) {
    my ($v,$n) = @_;
    my $ret = "";
    for($n -= 1; $n >= 0; $n -= 1) {
	$ret .= substr($itoa64, $v & 0x03f, 1);
	$v = ($v >> 6) & 0x01ffffff;
    }
    $ret;
}

sub bsdencode($) {
    my ($v) = @_;
    my @va;
    my $l;
    my $ret;
    $ret = '';
    @va = unpack("C*",$v);
    $l = ($va[0] << 16) | ($va[6] << 8) | $va[12]; $ret .= to64($l,4);
    $l = ($va[1] << 16) | ($va[7] << 8) | $va[13]; $ret .= to64($l,4);
    $l = ($va[2] << 16) | ($va[8] << 8) | $va[14]; $ret .= to64($l,4);
    $l = ($va[3] << 16) | ($va[9] << 8) | $va[15]; $ret .= to64($l,4);
    $l = ($va[4] << 16) | ($va[10] << 8) | $va[5]; $ret .= to64($l,4);
    $l =                   $va[11];                $ret .= to64($l,2);
    return $ret;
}

#
# Exceedingly lame multi-context MD5 support.
#
my @contexts = ('','');

sub md5init($) {
    my ($cn) = @_;
    $contexts[$cn] = '';
}
sub md5update($$) {
    my ($cn,$v) = @_;
    $contexts[$cn] .= $v;
}
sub md5updateN($$$) {
    my ($cn,$v,$len) = @_;
    $contexts[$cn] .= substr($v,0,$len);
}
sub md5final($) {
    my ($cn) = @_;
    return md5($contexts[$cn]);
}

#
# BSD crypt(3) function implemented in Perl;
# a BSD crypt uses a jumble of MD5, both nested and
# iterated 1000x to make dictionary attacks on passwords
# very expensive.  It also uses a salt, blended in 
# periodically throughout the computation, to make
# pre-computation useless.  Cisco IOS 12 adopts the
# BSD algorithm completely and even uses the same
# encoding format, except that BSD usually uses an
# 8-character salt where IOS seems to prefer a 4-char
# salt.
# 
sub bsdcrypt($$) {
    my ($pw,$salt) = @_;
    my $magic = q/$1$/;
    my $final;
    my $ret;
    my $i;
    my $pl;
    my $sp = $salt;
    if ($salt =~ m/^\$?1?\$?([^\$]+)\$.*/) {
	$sp = $1;
    }

    md5init(0);
    md5update(0,$pw);
    md5update(0,$magic);
    md5update(0,$sp);

    md5init(1);
    md5update(1,$pw);
    md5update(1,$sp);
    md5update(1,$pw);
    $final = md5final(1);
    for($pl = length($pw); $pl > 0; $pl -= 16) {
	md5updateN(0, $final, (($pl > 16)?(16):($pl)));
    }
    for($pl = length($pw); $pl != 0; $pl = $pl >> 1) {
	if (($pl & 1) != 0) {
	    md5update(0, "\0");
	} else {
	    md5updateN(0, $pw, 1);
	}
    }
    $final = md5final(0);

    for($i = 0; $i < 1000; $i += 1) {
	md5init(1);
	if (($i & 1) != 0) {
	    md5update(1,$pw);
	} else {
	    md5update(1,$final);
	}
	if (($i % 3) != 0) {
	    md5update(1,$sp);
	}
	if (($i % 7) != 0) {
	    md5update(1,$pw);
	}
	if (($i & 1) != 0) {
	    md5update(1,$final);
	} else {
	    md5update(1,$pw);
	}
	$final = md5final(1);
    }
    $ret = $magic . $sp . "\$" . bsdencode($final);
    return $ret;
}

#
# check whether a given plaintext password (arg 2)
# encrypts to the same value (using the same salt) as a
# given BSD-encrypted password (arg 1). 
#
sub testCandidatePassword($$) {
    my ($knownEPW,$candidate) = @_;
    my $newEPW;
    $newEPW = bsdcrypt($candidate,$knownEPW);
    return ($newEPW eq $knownEPW);
}


# do not remove this trailer

1;

__END__
