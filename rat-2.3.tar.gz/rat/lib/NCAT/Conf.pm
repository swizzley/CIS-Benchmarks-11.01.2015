package NCAT::Conf;
use strict;
use NCAT::ConfObj;
use NCAT::ConfGlobal;
use NCAT::ConfClass;
use NCAT::ConfData;
use NCAT::ConfRule;

# hide pseudo-hash warning in 5.8
no warnings 'deprecated';

=head1 NAME

NCAT::ConfConf - Class to implement NCAT config file read/writing/operations

=head1 SYNOPSIS

  use 'NCAT::Conf';

o  # create new object

  $conf = new NCAT::Conf(filename=>"conf.txt",
			 fields_filename=>"fields.txt",
			 context_filename=>"fields.txt");

  # Field names/purpose
  #   filename		- config filename
  #   fields_filename	- fields definition filename
  #   context_filename	- context defs filename



  # set access methods

  $conf->filename("conf.txt");
  $conf->fields_filename("fields.txt");
  $conf->context_filename("context.txt");

  $ get methods

  $filename = $conf->filename;
  $fields = $conf->fields_filename;
  $conf = $conf->$conf;
  @context_defs = $conf->context_defs;

  # other methods

  $success  = $conf->parse;

=head1 DESCRIPTION

  This module defines operations on NCAT config files.

=head1 AUTHOR

George M. Jones

=head1 SEE ALSO

NCAT::ConfData, NCAT::ConfObject

=cut

use fields qw(filename fields_filename context_filename context_defs conf objects);

# Data Types:
#
#	ConfigClass	- Basic config object.  Has a name, description,
#			  can have chilren (which can be rules or data objects),
#			  and a yes/no question to determine
#			  if the class is seelcted.
#
#	ConfigData	- A basic config object with the same atributes of a class,
#			  with the addition of a value field and a default field.
#
#	ConfigRules	- A basic config object with many rule-specific fields
#			  added.
#
#	ConfigGlobalFieldNames
#			- Field names for global config values
#
#	ConfigGlobalFieldValues
#			- Global config values


#
# Define keywords for fields and regexps that tell what values they can take
#


#
# Rule Fields Names.  Key = field name.  Value = regexp for acceptable values.
#
our %ConfigRuleFieldNames;

#
# List Rule Field names that must be defined for each rule
#
our @RequiredConfigRuleFields;

#
# Define fields global to the config.
#   Key=field name.  Value=regexp for acceptable values.
#
our %ConfigGlobalFieldNames;

#
# List field names that must be defined in each config.
#
#@RequiredGloalFieldNames:...

#
# Values for global config items
#
our %ConfigGlobalFieldValues;

#
# Define fields for config classes
#   Key=field name.  Value=regexp for acceptable values.
#
our %ConfigClassFieldNames;
our @RequiredConfigClassFields;

#
# Define fields for data fields
#   Key=field name.  Value=regexp for acceptable values.
#
our %ConfigDataFieldNames;
our @RequiredConfigDataFields;

#
# New conf file object
#

sub new {
  my NCAT::Conf $self = shift;
  unless (ref $self) {
    $self = fields::new($self);
  }

  # set defaults

  $self->{filename} = "ncat.conf";
  $self->{fields_filename} = "fields.conf";
  $self->{context_filename} = "";
  $self->{context_defs} = [];
  $self->{conf} = new NCAT::ConfObj(name=>"root node");
  $self->{objects} = 0;

  # override defaults

  my ($key,$value);

  while (($key = shift) and ($value = shift)) {
    $self->{$key} = $value;
  }

  # Check for required values

  unless (defined($self->{filename})) {
    warn("NCAT::Conf->new requires a filename");
    return undef;
  }

  unless (defined($self->{fields_filename})) {
    warn("NCAT::Conf->new requires a fields_filename");
    return undef;
  }

  #
  # Read and parse context definitions
  # 

  my $context_filename = defined $self->context_filename ? $self->context_filename : "";

  if ($context_filename ne "") {
    open(CONTEXT,"<$context_filename") || die "Can't open $context_filename: $!";

    while (<CONTEXT>) {
      chomp;
      next if (/^\s*#/);  #skip comments
      next if (/^\s*$/);  #skip blank lines
      push @{$self->{context_defs}}, $_;
    }

    close(CONTEXT);
  }


  return $self;
}

#
# Access methods
#

sub filename {
  my NCAT::Conf $self = shift;
  $self->{filename} = shift if @_;
  return $self->{filename};
}

sub fields_filename {
  my NCAT::Conf $self = shift;
  $self->{fields_filename} = shift if @_;
  return $self->{fields_filename};
}

sub context_filename {
  my NCAT::Conf $self = shift;
  $self->{context_filename} = shift if @_;
  return $self->{context_filename};
}

sub context_defs {
  my NCAT::Conf $self = shift;
  $self->{context_defs} = shift if @_;
  return @{$self->{context_defs}};
}

sub conf {
  my NCAT::Conf $self = shift;
  $self->{conf} = shift if @_;
  return $self->{conf};
}

sub objects {
  my NCAT::Conf $self = shift;
  $self->{objects} = shift if @_;
  return $self->{objects};
}

#
# Parse
#

sub parse {
  my NCAT::Conf $self = shift;
  my $skip = shift || "";
  my NCAT::ConfData $parent;
  my NCAT::ConfData $child;
  my NCAT::ConfGlobal $global;

  my ($line,$lineno) = ("",0);	#curret line, line number
  my (@ConfigLines) = ();	# saved config lines
  my ($CurrentRuleName,		# name of rule being parsed
      $CurrentClassName,	# name of class being parsed	
      $CurrentDataName);	# name of local data being parsed

  my ($keyword,$keyword_lc,$text,$text_lc);

  my $filename = $self->filename;
  my $fields_filename = $self->fields_filename;

  #
  # Read and parse field definitions
  #

  open(FIELDS,"<$fields_filename") || die "Can't open $fields_filename: $!";

  while(<FIELDS>) {
    my @fields = ();
    my $char = undef;
    my ($type,$name,$value) = (undef,undef,undef);

    no strict 'refs';

    chomp;

    next if ((/^\s*\#/) or (/^\s*$/));

    @fields = split(/:/,$_);

    print "fields: " . join(",", @fields) . "\n"
      if ($main::opt_debug =~ /fields/);

    if (@fields == 3) {
      ($type,$name,$value) = @fields;
    } elsif (@fields == 2) {
      ($type,$value) = @fields;
    } else {
      warn "Warning: Not enough fields in $fields_filename (/$_/)";
      next;
    }
    
    $char = substr($type,0,1) if ($type);
    $type = substr($type,1) if ($type);
    
    if ($char eq '%') {
      next unless ((defined $type) and
		   (defined $name) and
		   (defined $value)  #and
		   #(defined %{$type})
		  );
      print "defining \$$type"."{$name} = /$value/\n"
	if ($main::opt_debug =~ /fields/);

      ${$type}{lc $name} = $value;
    } elsif ($char eq '@') {
      next unless ((defined $type) and
		   (defined $value) #and
		   #(defined @{$type})
		  );

      print "defining \@type = ($value)\n"
	      if ($main::opt_debug =~ /fields/);

      @{$type} = (split(/,/,$value));
    } elsif ($char eq '\$') {
      next unless ((defined $type) and
		   (defined $value) #and
		   #(defined ${$type})
		  );
      print "defining \$type = $value\n"
	if ($main::opt_debug =~ /fields/);

      ${$type} = $value;
    } else {
      warn "Warning: First character must be '%', '\@' or '$' in $fields_filename (/$_/)";
    }
	     
  }

  close(FIELDS);

  #
  # Read and parse config file
  #

  open(CONF,"<$filename") ||
    die "Can't open $filename. $!";

  while(<CONF>) {

    $line = $_;
    $lineno++;
    
    s/\s+$//; # strip trailing blanks
    chomp;
    push @ConfigLines,$_;  # save (nearly) raw config lines

    next if (/^\s*[#!]/); # skip lines with leading comments

      if (/^\s*$/) {
	  $CurrentRuleName = ""; # blank line ends RuleName record
	  $CurrentClassName = ""; # blank line ends ConfigClass record
	  $CurrentDataName = ""; # blank line ends ConfigClass record
	  next; # skip blank lines
      } 

      s/^\s*[#!].*//; # strip trailing comments      
  

    # Parse Interesting lines and save them

    if (/^\s*(\w+):(.*)/) {
	$keyword = $1;
	$text = defined($2) ? $2 : "";

	# store lower case versions.  These are used for
	# call comparison, hash indexes, etc.  The non-downcased
	# version are used for display.

	$keyword_lc = lc($keyword);  

	# handle continuation lines
	
	while ($text =~ /\\$/s) {
	    $text =~ s/\n$//s;
	    $text =~ s/\\$/\n/s;
	    $_ = <CONF> || last;
	    $lineno++;
	    $text .= $_;
	}

	$text_lc = lc($text);

	#
	# Process various keywords
	#

	# Global Config Keywords
	
	if (defined($ConfigGlobalFieldNames{$keyword_lc})) {

	    # Save config global values
	    
	    die("Bad value for ConfigGlobalFieldNames $keyword. /$text/ does not match /^$ConfigGlobalFieldNames{$keyword_lc}\$/ in $filename")
		unless ($text_lc =~ /^$ConfigGlobalFieldNames{$keyword_lc}$/si);

	    # save definitions under "Config Globals"

	    unless ($parent = $self->conf->lookup("Config Globals")) {
	      $parent = new NCAT::ConfClass(name=>"Config Globals",selected=>"yes");
	      $self->conf->add_child($parent)
	    }

	    # Warn about redefinition of config global

	    $global = $self->conf->lookup($keyword);

	    if ($global) {
	      warn "Warning: /$global->{'name'}/ redefined as /$text/.  Was /$global->{'value'}/"
		  if ($main::opt_debug =~ /dups/);
	      $global->{'value'} = $text;
	  } else {
	      $global = new NCAT::ConfGlobal(name=>"$keyword",value=>$text);
	      $global->parseorder(++$self->{objects});
	      $parent->add_child($global);
	  }
	    
	# Rules
	    
	  } elsif (defined($ConfigRuleFieldNames{$keyword_lc})) {

	    #
	    # Syntax check of keyword value
	    #
	    
	    die("Bad value for ConfigRuleFieldNames $keyword. /$text/ does not match /^$ConfigRuleFieldNames{$keyword_lc}\$/ in $filename")
	      unless ($text_lc =~ /^$ConfigRuleFieldNames{$keyword_lc}$/si);
	    
	    #
	    # deal with new rule
	    #
	    
	    if ($keyword =~ /ConfigRuleName$/i) {
	      $CurrentRuleName = $text;

	      # Make sure we have "Config Rules", add to root node
	      
	      unless ($parent = $self->conf->lookup("Config Rules")) {
		$parent = new NCAT::ConfClass(name=>"Config Rules",selected=>"yes");
		$self->conf->add_child($parent)
	      }

	      # Lookup or create child node, add to "Config Rules" list

	      if ($child = $self->conf->lookup($CurrentRuleName)) {
		 warn "Warning: Rule /$CurrentRuleName/ redefined" if ($main::opt_debug =~ /dups/);
	     } else {
		 $child = new NCAT::ConfRule(name=>$CurrentRuleName);
		 $child->parseorder(++$self->{objects});
		 $parent->add_child($child);
	     }

	    } # if ConfigRuleName

	    #
	    # Add extra attributes
	    #
	    
	    print STDERR "rule: /$CurrentRuleName/, keyword: /$keyword/, text: /$text/\n"
	      if ($main::opt_debug =~ /config/i);

	    # extract method name from field anme

	    my $method = $keyword;
	    $method =~ s/ConfigRule//i;
	    $method = lc $method;

	  # set selected value per default answer

	  if ($method =~ /selected/) {
	      $child->selected("no") if ($text =~ /no/i);
	      $child->selected("yes") if ($text =~ /yes/i);
	  }

	    # Warn about redfinitions

	    if ($main::opt_debug =~ /dups/) {
	      if (defined $child->{$method}
		  and $child->{$method} ne ""
		  
		  # overwriting default values is OK.  No warning.

		  and not ($method =~ /type/i and $child->{$method} =~ /Required/i)
		  and not ($method =~ /description/i and $child->{$method} =~ /Default Description/i)
		  and not ($method =~ /selected/i and $child->{$method} =~ /yes/i)
		  and not ($method =~ /importance/i and $child->{$method} == 5)


		  # name will redefined each time here.  Don't warn.
		  
		  and not $method =~ /^name$/i
		 ) {
		warn "Warning: /$child->{'name'}/ field /$method/ redefined as /$text/.  Was /$child->{$method}/";
	      }
	    }

	    $child->$method("$text");

#
#	# Classes
#
	} elsif (defined($ConfigClassFieldNames{$keyword_lc})) {

	  no strict 'refs';

	    #
	    # Syntax check of keyword value
	    #
	    
	    die("Bad value for ConfigClassFieldNames $keyword. /$text/ does not match /^$ConfigClassFieldNames{$keyword_lc}\$/ in $filename")
	      unless ($text_lc =~ /^$ConfigClassFieldNames{$keyword_lc}$/si);
	    
	    #
	    # deal with new class
	    #
	    
	    if ($keyword =~ /ConfigClassName$/i) {
	      $CurrentClassName = $text;

	      # Make sure we have "Config Classes", add to root
	      
	      unless ($parent = $self->conf->lookup("Config Classes")) {
		$parent = new NCAT::ConfClass(name=>"Config Classes",selected=>"yes");
		$self->conf->add_child($parent)
	      }

	      # Lookup or create child node, add to "Config Classes"


	      if ($child = $self->conf->lookup($CurrentClassName)) {
		  warn "Warning: Class /$CurrentClassName/ redefined" if ($main::opt_debug =~ /dups/);
	      } else {
		  $child = new NCAT::ConfClass(name=>$CurrentClassName,selected=>"no");
		  $child->parseorder(++$self->{objects});
		  if ($skip ne "" and $CurrentClassName =~ /$skip/) {
		    print "Skipping: $CurrentClassName.  Not adding as child of 'ConfigClasses'\n"
		      if ($main::opt_debug =~ /skip/)
		  } else {
		    $parent->add_child($child)
		  }
	      }

	    } # if ConfigClassName
	    
	    #
	    # Add extra attributes
	    #
	    
	    print STDERR "class: /$CurrentClassName/, keyword: /$keyword/, text: /$text/\n"
	      if ($main::opt_debug =~ /config/i);

	    # extract method name from field anme

	    my $method = $keyword;
	    $method =~ s/ConfigClass//i;
	    $method = lc $method;

	  # set selected value per default answer

	  if ($method =~ /selected/) {
	      $child->selected("no") if ($text =~ /no/i);
	      $child->selected("yes") if ($text =~ /yes/i);
	  }

	  # Warn about redfinitions

	  if ($main::opt_debug =~ /dups/) {
	    if (defined $child->{$method}
		and $child->{$method} ne ""

		# overwriting default values is OK.  No warning.

		and not ($method =~ /description/i and $child->{$method} =~ /Default Description/i)
		and not ($method =~ /selected/i and $child->{$method} =~ /yes/i)

		# name will redefined each time here.  Don't warn.

		and not $method =~ /^name$/i
	       ) {
	      warn "Warning: /$child->{'name'}/ field /$method/ redefined as /$text/.  Was /$child->{$method}/";
	    }
	  }

	  $child->$method("$text");

	  # Data

	} elsif (defined($ConfigDataFieldNames{$keyword_lc})) {

	  #
	  # Add data fields.
	  #
	  # Note: all these add data/class/rule procedures are very
	  # similar.  It would be good if they were done via a
	  # common routine.  ---gmj 11/1/02
	  #

	  no strict 'refs';

	    #
	    # Syntax check of keyword value
	    #
	    
	    die("Bad value for ConfigDataFieldNames $keyword. /$text/ does not match /^$ConfigDataFieldNames{$keyword_lc}\$/ in $filename")
	      unless ($text_lc =~ /^$ConfigDataFieldNames{$keyword_lc}$/si);
	    
	    #
	    # deal with new class
	    #
	    
	    if ($keyword =~ /ConfigDataName$/i) {
	      $CurrentDataName = $text;

	      # Make sure we have "Config Data", add to root node

	      unless ($parent = $self->conf->lookup("Config Data")) {
		$parent = new NCAT::ConfClass(name=>"Config Data",selected=>"yes");
		$self->conf->add_child($parent)
	      }

	      # Lookup or create child node, add to "Config Data" list


	      if ($child = $self->conf->lookup($CurrentDataName)) { 
		  warn "Warning: Data /$CurrentClassName/ redefined" if ($main::opt_debug =~ /dups/);
	      } else {
		  $child = new NCAT::ConfData(name=>$CurrentDataName,selected=>"no");
		  $child->parseorder(++$self->{objects});
		  $parent->add_child($child);
	      }

	    } # if ConfigDataName
	    
	    #
	    # Add extra attributes
	    #
	    
	    print STDERR "data: /$CurrentDataName/, keyword: /$keyword/, text: /$text/\n"
	      if ($main::opt_debug =~ /config/i);

	    # extract method name from field anme

	    my $method = $keyword;
	    $method =~ s/ConfigData//i;
	    $method = lc $method;

	  # set selected value per default answer

	  if ($method =~ /selected/) {
	      $child->selected("no") if ($text =~ /no/i);
	      $child->selected("yes") if ($text =~ /yes/i);
	  }


	  # Warn about redfinitions

	  if ($main::opt_debug =~ /dups/) {
	    if (defined $child->{$method}
		and $child->{$method} ne ""

		# overwriting default values is OK.  No warning.

		and not ($method =~ /description/i and $child->{$method} =~ /Default Description/i)

		# name will redefined each time here.  Don't warn.

		and not $method =~ /^name$/i
	       ) {
	      warn "Warning: /$child->{'name'}/ field /$method/ redefined as /$text/.  Was /$child->{$method}/";
	    }
	  }

	    $child->$method("$text");

	} else {
	    die("unknown rules file keyword /$keyword/ in $filename");
	}
	
    } else {
	warn "Warning: skipping line $lineno in $filename. Bad Format.\n/$line/";
    }
	     
  # 
  # Check for required attributes for each rule
  #

  } # while more CONF lines
  close(CONF);

  my ($childname);		   

  foreach $childname ($self->conf->object_names) {

    $child = $self->conf->lookup($childname);

    validate_object($child);

  }
  		   
  return 1;
}

#
# Attach children to named parents,
# Attach parents to named children.
#	     

sub attach_children {
  my NCAT::Conf $self = shift;
  my NCAT::ConfObj $parent;
  my NCAT::ConfObj $child;
  my ($parentname,$childname,$undefined_parent);

  #
  # Attach children to explicitly listed parent
  #


  foreach $childname ($self->conf->object_names) {

    $child = $self->conf->lookup($childname);

    next unless defined($child->{parentname}); 
    
    foreach $parentname (split(/,/,$child->{parentname})) {
      
      $undefined_parent = 0;
      
      $parent = $self->conf->lookup($parentname);
      
      unless ($parent) {
	warn("Warning: /$childname/ is defined as being a child of /$parentname/, but /$parentname/ is not defined");
	$undefined_parent = 1;
      }
      
      next if ($undefined_parent);

      # Add child, but don't add duplicaets

      my %children = $parent->children_names;

      if (defined $children{$childname}) {
#	warn("Warning: /$childname/ is alerady defined as being a child of /$parentname/");
      } else {
	$parent->add_child($child);
      }

    } # foreach listed parent
  } # foreach object


  #
  # Attach explicitly listed children
  #

  foreach $parentname ($self->conf->object_names) {

    # Get each parent object

    $parent = $self->conf->lookup($parentname);
      
    unless ($parent) {
      warn("Warning: unable to lookup object /$parentname/");
      next;
    }

    $parentname = $parent->{name};

    # skip unless it requres children

    next unless defined($parent->{childrenneeded}) and
      $parent->{childrenneeded} ne "";

    # add each child, unless already added

    my %children = $parent->children_names;
    
    foreach $childname (split(/,/,$parent->{childrenneeded})) {

      # skip if child is already attached

      if (defined $children{$childname}) {
#	warn("Warning: /$childname/ is already defined as a child of /$parentname/");
	next;
      }

      # warn if requested child is not defined.

      $child = $self->conf->lookup($childname);
      unless ($child) {
	warn("Warning: /$childname/ is defined as being a child of /$parentname/, but /$childname/ is not defined");
	next;
      }

      # Add child

      $parent->add_child($child);

    } # foreach listed child
  } # foreach parent

} # attach children

#
# Validate a single object
#


sub validate_object {
  my $self = shift;
  my NCAT::ConfObj $obj;

  unless(defined $self->{name} and $self->{name} ne "") {
    warn("Unnamed object");
    return 0;
  }

  #
  # Perform validity checks on classes, rules, data
  #

  # exempt special classes

  return 1 if (($self->{name}    =~ /^Config Classes$/) 
	       or ($self->{name} =~ /^Config Rules$/) 
	       or ($self->{name} =~ /^Config Data$/) 
	       or ($self->{name} =~ /^Config Globals$/) 
	       or ($self->{name} =~ /^root node$/) 
	       or ($self->{name} =~ /^Selectable$/) 
	       or ($self->isa("NCAT::ConfGlobal"))
	      );

  # check all other cases


  #
  #  All objects must:
  #  - Have a parent name
  #  - Named parent must exist
  #

  my ($objname,$object,$required);

  $objname = $self->{name};
	     
  $object = $self;
  
  if ($object->isa("NCAT::ConfClass")) {
    
    foreach $required (@RequiredConfigClassFields) {
      
      $required =~ s/ConfigClass//i;

      die "Required attribute /$required/ not defined for class /$objname/"
	unless (defined $object->{$required} and $object->{$required} ne "");
    } # while more required fields
    
  } elsif ($object->isa("NCAT::ConfData")) {

    foreach $required (@RequiredConfigDataFields) {
      
      $required =~ s/ConfigData//i;

     die "Required attribute /$required/ not defined for class /$objname/"
	unless (defined $object->{$required} and $object->{$required} ne "");
    } # while more required fields
    

  } elsif ($object->isa("NCAT::ConfRule")) {

    foreach $required (@RequiredConfigRuleFields) {
      
      $required =~ s/ConfigRule//i;

      die "Required attribute /$required/ not defined for class /$objname/"
	unless (defined $object->{$required} and $object->{$required} ne "");
    } # while more required fields
    
  } else {
  }
  
  
  return 1;
}



1;
